USE ROLE SYSADMIN;
USE DATABASE dev_ent_presentation_db;
USE SCHEMA sales;
USE WAREHOUSE dev_ent_service_elt_whs;

--adding new fact Column
ALTER TABLE fact_order_price
    ADD COLUMN discount_amt DECIMAL(12,2);

--populating new column with extendedprice x discount x quantity to obtain total discount amount for the existing records
UPDATE fact_order_price fop
    SET discount_amt = (dos.extended_price * dos.discount * dos.quantity)
FROM dim_orders dos
    WHERE dos.order_line_id = fop.order_line_id;
