USE ROLE SYSADMIN;
USE DATABASE dev_ent_integration_db;
USE SCHEMA derived;
USE WAREHOUSE dev_ent_service_elt_whs;

--CLONE Order details table from production to the development database as it was 30 minutes ago
CREATE OR REPLACE TABLE
  dev_ent_integration_db.derived.order_details
CLONE prd_ent_integration_db.derived.order_details AT (OFFSET => -1800);
