USE ROLE SYSADMIN;
USE DATABASE dev_ent_presentation_db;
USE SCHEMA sales;
USE WAREHOUSE dev_ent_service_elt_whs;

--Write additional query against presentation in DEV to show top 10 parts with highest discount

SELECT dp.name
     , fop.discount_amt
FROM fact_order_price fop
    INNER JOIN dim_parts dp
    ON dp.part_id=fop.part_id
    ORDER BY discount_amt DESC
    LIMIT 10;
