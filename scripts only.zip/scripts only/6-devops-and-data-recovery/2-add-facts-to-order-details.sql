USE ROLE SYSADMIN;
USE DATABASE dev_ent_integration_db;
USE SCHEMA derived;
USE WAREHOUSE dev_ent_service_elt_whs;

/*adding new fact table column*/
ALTER TABLE order_details ADD COLUMN discount_amt NUMBER(12,2);


/* existing record would need to be updated with the derived value*/
UPDATE order_details
   SET discount_amt = (extended_price * discount);
