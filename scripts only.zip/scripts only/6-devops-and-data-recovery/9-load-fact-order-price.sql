USE ROLE SYSADMIN;
USE DATABASE dev_ent_presentation_db;
USE SCHEMA sales;
USE WAREHOUSE dev_ent_service_elt_whs;

/* The insert below should only accommodate for just the delta records, but for this exercise,
we will reload the script with the additional column and overwrite the existing records, ideally this should be carried out as part of the ETL scripts */
INSERT OVERWRITE INTO fact_order_price (customer_id, order_line_id, quantity, part_id, unit_price, tax_amt,discount_amt)
    SELECT    c.customer_id
            , dol.order_line_id
            , dol.quantity
            , dp.part_id
            , dol.extended_price / dol.quantity AS unit_price
            , (dol.extended_price - (dol.extended_price * dol.discount)) * dol.tax AS tax_amt
            , dol.extended_price * dol.discount as discount_amt
    FROM (
        SELECT co.payload:custkey::INTEGER AS customer_key
                , co.payload:orderkey::INTEGER AS order_key
                , li.value:linenumber::INTEGER AS line_number
                , li.value:part:partkey::INTEGER AS part_key
        FROM  prd_ent_order_source_db.orders.orders co,
        LATERAL FLATTEN(INPUT => co.payload, PATH => 'lineitems') li
    ) li
    INNER JOIN sales.dim_orders dol
    ON dol.order_key = li.order_key
    AND dol.line_number = li.line_number
    INNER JOIN sales.dim_parts dp
    ON dp.part_key = li.part_key
    INNER JOIN dim_customer c
    ON c.customer_key = dol.customer_key;
