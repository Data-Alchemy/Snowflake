USE ROLE SYSADMIN;
USE DATABASE dev_ent_presentation_db;
USE SCHEMA sales;
USE WAREHOUSE dev_ent_service_elt_whs;

--Verify that the extendedprice x discount x quantity calculation in dim_orders equals the associated value in discount_amt in fact_order_price
SELECT COUNT(*)
FROM fact_order_price fop
JOIN sales.dim_orders dol
ON dol.order_line_id = fop.order_line_id
WHERE (((to_number(dol.extended_price,12,2)) * to_number(dol.discount,12,2) * to_number(dol.quantity,12,2))::number(12,2)) <> fop.discount_amt ;
--Should return 0 count


--Verification to see if there are any discount_amount that has not updated
SELECT COUNT(*)
FROM  fact_order_price
WHERE discount_amt IS NULL;
--Should return zero count
