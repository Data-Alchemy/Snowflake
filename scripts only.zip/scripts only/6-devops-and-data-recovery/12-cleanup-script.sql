-- CLEAN UP Scripts
USE ROLE SYSADMIN;
USE DATABASE dev_ent_integration_db;
USE SCHEMA derived;
USE WAREHOUSE dev_ent_service_elt_whs;

DROP TABLE IF EXISTS dev_ent_presentation_db.sales.dim_customer ;
DROP TABLE IF EXISTS dev_ent_presentation_db.sales.dim_orders ;
DROP TABLE IF EXISTS dev_ent_presentation_db.sales.dim_parts ;
DROP TABLE IF EXISTS dev_ent_presentation_db.sales.fact_order_price;
DROP TABLE IF EXISTS dev_ent_presentation_db.sales.fact_order_price1;
DROP TABLE IF EXISTS dev_ent_integration_db.DERIVED.order_details1;
DROP TABLE IF EXISTS dev_ent_integration_db.DERIVED.order_details;
