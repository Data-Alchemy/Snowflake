USE ROLE SYSADMIN;
USE DATABASE dev_ent_integration_db;
USE SCHEMA derived;
USE WAREHOUSE dev_ent_service_elt_whs;

--Verification to see if there are any discount_amount that has not updated
SELECT COUNT(*) FROM order_details WHERE discount_amt IS NULL;
--zero count should return
