USE ROLE SYSADMIN;
USE DATABASE dev_ent_integration_db;
USE SCHEMA derived;
USE WAREHOUSE dev_ent_service_elt_whs;

--We can undo the changes if the fact table fact_order_price change plans are dropped/clean up script

CREATE OR REPLACE TABLE dev_ent_presentation_db.sales.fact_order_price1
    CLONE dev_ent_presentation_db.sales.fact_order_price AT (OFFSET => -300);

DESC TABLE dev_ent_presentation_db.sales.fact_order_price1;

ALTER TABLE dev_ent_presentation_db.sales.fact_order_price1 SWAP
    WITH dev_ent_presentation_db.sales.fact_order_price;

SELECT COUNT(*)
FROM dev_ent_presentation_db.sales.fact_order_price;

-- The same steps needs to be carried to undo changes in the prod environment.


--We can undo the changes if the fact table order_details change plans are dropped/clean up script

CREATE OR REPLACE TABLE dev_ent_integration_db.derived.order_details1
   CLONE dev_ent_integration_db.derived.order_details AT (OFFSET => -300);

DESC TABLE dev_ent_integration_db.derived.order_details1;

ALTER TABLE dev_ent_integration_db.derived.order_details1
    SWAP WITH dev_ent_integration_db.derived.order_details;
