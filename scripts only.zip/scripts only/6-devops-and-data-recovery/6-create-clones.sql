--Cloning adding new fact column in the Presentation layer
USE ROLE SYSADMIN;
USE DATABASE dev_ent_presentation_db;
USE SCHEMA sales;
USE WAREHOUSE dev_ent_service_elt_whs;

--Cloning relevant tables from PROD to Dev as it was an 30 minutes ago
CREATE OR REPLACE TABLE dev_ent_presentation_db.sales.dim_customer
    CLONE prd_ent_presentation_db.sales.dim_customer AT (OFFSET => -1800) ;
CREATE OR REPLACE TABLE dev_ent_presentation_db.sales.dim_orders
    CLONE prd_ent_presentation_db.sales.dim_orders AT (OFFSET => -1800);
CREATE OR REPLACE TABLE dev_ent_presentation_db.sales.dim_parts
    CLONE prd_ent_presentation_db.sales.dim_parts AT (OFFSET => -1800);
CREATE OR REPLACE TABLE dev_ent_presentation_db.sales.fact_order_price
    CLONE prd_ent_presentation_db.sales.fact_order_price AT (OFFSET => -1800);
