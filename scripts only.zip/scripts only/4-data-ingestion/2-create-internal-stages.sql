--create_internal_stages.sql
USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_common_db;
USE SCHEMA CORE;

CREATE OR REPLACE STAGE prd_ent_common_db.core.int_stg_crm
FILE_FORMAT = (FORMAT_NAME = 'PRD_ENT_COMMON_DB.CORE.FF_CSV')
COMMENT = 'Internal stage for loading CSV Files'
;

CREATE OR REPLACE STAGE prd_ent_common_db.core.int_stg_order_source
FILE_FORMAT = (FORMAT_NAME = 'PRD_ENT_COMMON_DB.CORE.FF_JSON')
COMMENT = 'Internal stage for loading JSON files'
;
