USE ROLE ent_service_elt_role;
USE WAREHOUSE prd_ent_service_elt_whs;

-- validate region record counts by r_regionkey
-- following query should return 0 rows
WITH src as (
  SELECT
      r_regionkey as key
    , count(*) record_count
  FROM prd_ent_crm_db.staging.region_raw
  GROUP BY 1
),
tgt as (
  SELECT
      r_regionkey as key
    , count(*) record_count
  FROM prd_ent_crm_db.common.region
  GROUP BY 1
)
SELECT
    src.*
  , tgt.key as target_key
  , tgt.record_count as target_record_count
FROM src
LEFT OUTER JOIN tgt ON tgt.key = src.key
WHERE COALESCE(src.record_count,-1) <> COALESCE(tgt.record_count, -1)
;

-- validate nation record counts by n_nationkey
-- following query should return 0 rows
WITH src as (
  SELECT
      n_nationkey as key
    , count(*) record_count
  FROM prd_ent_crm_db.staging.nation_raw
  GROUP BY 1
),
tgt as (
  SELECT
      n_nationkey as key
    , count(*) record_count
  FROM prd_ent_crm_db.common.nation
  GROUP BY 1
)
SELECT
    src.*
  , tgt.key as target_key
  , tgt.record_count as target_record_count
FROM src
LEFT OUTER JOIN tgt ON tgt.key = src.key
WHERE COALESCE(src.record_count,-1) <> COALESCE(tgt.record_count, -1)
;

-- validate customers record count by custkey
-- following query should return 0 rows
WITH src as (
  SELECT
      c_custkey as key
    , count(*) record_count
  FROM prd_ent_crm_db.staging.customer_raw
  GROUP BY 1
),
tgt as (
  SELECT
      c_custkey as key
    , count(*) record_count
  FROM prd_ent_crm_db.customers.customer
  GROUP BY 1
)
SELECT
    src.*
  , tgt.key as target_key
  , tgt.record_count as target_record_count
FROM src
LEFT OUTER JOIN tgt ON tgt.key = src.key
WHERE COALESCE(src.record_count,-1) <> COALESCE(tgt.record_count, -1)
;

-- validate orders record count by orderkey
-- following query should return 0 rows
WITH src as (
  SELECT
      payload:orderkey::number as key
    , count(*) record_count
  FROM prd_ent_order_source_db.staging.orders_raw
  GROUP BY 1
),
tgt as (
  SELECT
      payload:orderkey::number as key
    , count(*) record_count
  FROM prd_ent_order_source_db.orders.orders
  GROUP BY 1
)
SELECT
    src.*
  , tgt.key as target_key
  , tgt.record_count as target_record_count
FROM src
LEFT OUTER JOIN tgt ON tgt.key = src.key
WHERE COALESCE(src.record_count,-1) <> COALESCE(tgt.record_count, -1)
;
