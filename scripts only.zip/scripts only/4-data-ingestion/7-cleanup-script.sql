USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_common_db;
USE SCHEMA CORE;

DROP FILE FORMAT IF EXISTS prd_ent_common_db.core.FF_JSON;
DROP FILE FORMAT IF EXISTS prd_ent_common_db.core.FF_CSV;
DROP STAGE IF EXISTS prd_ent_common_db.core.ext_stg_crm;
DROP STAGE IF EXISTS prd_ent_common_db.core.ext_stg_order_source;
DROP STAGE IF EXISTS prd_ent_common_db.core.int_stg_crm;
DROP STAGE IF EXISTS prd_ent_common_db.core.int_stg_order_source;
DROP TABLE IF EXISTS prd_ent_crm_db.staging.customer_raw;
DROP TABLE IF EXISTS prd_ent_crm_db.staging.nation_raw;
DROP TABLE IF EXISTS prd_ent_crm_db.staging.region_raw;
DROP TABLE IF EXISTS prd_ent_order_source_db.staging.orders_raw;
DROP TABLE IF EXISTS prd_ent_crm_db.customers.customer;
DROP TABLE IF EXISTS prd_ent_crm_db.common.nation;
DROP TABLE IF EXISTS prd_ent_crm_db.common.region;
DROP TABLE IF EXISTS prd_ent_order_source_db.orders.orders;
