USE ROLE mktg_datascience_adhoc_role;

USE WAREHOUSE prd_mktg_datascience_whs;

show databases;

-- following query should return result as 0
select
        'Database_Access' as validation_type
    ,   case when count(*) <> array_size(array_construct('PRD_ENT_ORDER_SOURCE_DB', 'PRD_ENT_CRM_DB')) then 1 else 0 end as result
from table(result_scan(last_query_id()))
where "name" in ('PRD_ENT_ORDER_SOURCE_DB', 'PRD_ENT_CRM_DB')
;

-- Following sql statements should not error out
select count(*)
from prd_ent_order_source_db.staging.orders_raw;

select count(*)
from prd_ent_crm_db.staging.region_raw;

select count(*)
from prd_ent_crm_db.staging.nation_raw;

select count(*)
from prd_ent_crm_db.staging.customer_raw;

select count(*)
from prd_ent_crm_db.common.region;

select count(*)
from prd_ent_crm_db.common.nation;

select count(*)
from prd_ent_crm_db.customers.customer;

select count(*)
from prd_ent_order_source_db.orders.orders;

--following update statement should fail with:
-- SQL access control error: Insufficient privileges to operate on table 'REGION_RAW'
update prd_ent_crm_db.staging.region_raw
set created_by = current_role()
where 1 = 2;

--following update statement should fail with:
-- SQL access control error: Insufficient privileges to operate on table 'NATION_RAW'
update prd_ent_crm_db.staging.nation_raw
set created_by = current_role()
where 1 = 2;

--following update statement should fail with:
-- SQL access control error: Insufficient privileges to operate on table 'CUSTOMER_RAW'
update prd_ent_crm_db.staging.customer_raw
set created_by = current_role()
where 1 = 2;

--following update statement should fail with:
-- SQL access control error: Insufficient privileges to operate on table 'REGION'
update prd_ent_crm_db.common.region
set created_by = current_role()
where 1 = 2;

--following update statement should fail with:
-- SQL access control error: Insufficient privileges to operate on table 'REGION'
update prd_ent_crm_db.common.nation
set created_by = current_role()
where 1 = 2;

--following update statement should fail with:
-- SQL access control error: Insufficient privileges to operate on table 'CUSTOMER'
update prd_ent_crm_db.customers.customer
set created_by = current_role()
where 1 = 2;

--following update statement should fail with:
-- SQL access control error: Insufficient privileges to operate on table 'ORDERS_RAW'
update prd_ent_order_source_db.staging.orders_raw
set created_by = current_role()
where 1 = 2;

--following update statement should fail with:
-- SQL access control error: Insufficient privileges to operate on table 'ORDERS'
update prd_ent_order_source_db.orders.orders
set created_by = current_role()
where 1 = 2;
