--Psuedo code and further instructions found in sql file here: https://drive.google.com/open?id=1EU6HiFUJgXW6B8Q_ivo_nAPj-walrLle
--Prepare files (provide script to customer, but complete steps before engagement)
--Create 2 Stage objects (external or internal) for unloading data
--External - if using customer cloud storage
-- Internal stage
USE ROLE SYSADMIN; 
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_common_db;
USE SCHEMA PUBLIC;

CREATE OR REPLACE STAGE cust1_orders_export
URL = 's3://snowflake-data-loading/export/orders'
CREDENTIALS = (AWS_KEY_ID='<key>' AWS_SECRET_KEY='<secret>' )
FILE_FORMAT = (TYPE = CSV ENCODING=UTF8 FIELD_OPTIONALLY_ENCLOSED_BY = '"')
COMMENT = 'stage location for customer orders export in csv format'
;

CREATE OR REPLACE STAGE cust1_orders_json_export
URL = 's3://snowflake-data-loading/export/orders'
CREDENTIALS = (AWS_KEY_ID='<key>' AWS_SECRET_KEY='<secret>' )
FILE_FORMAT = (TYPE = JSON STRIP_OUTER_ARRAY=TRUE STRIP_NULL_VALUES=TRUE)
COMMENT = 'stage location for customer orders export in json format'
;

-- export region into files
COPY INTO @cust1_orders_export/region FROM (
  SELECT *
  FROM sample_data.tpch_sf1.region
)
HEADER = TRUE;

COPY INTO @cust1_orders_export/nation FROM (
  SELECT *
  FROM sample_data.tpch_sf1.nation
)
HEADER = TRUE;

COPY INTO @cust1_orders_export/customer FROM (
  SELECT *
  FROM sample_data.tpch_sf1.customer c
  WHERE c.c_custkey in (
    SELECT o_custkey
    FROM sample_data.tpch_sf1.orders
  )
)
HEADER = TRUE;
;

COPY INTO @cust1_orders_json_export/orders FROM (
  SELECT
    object_construct(
      'orderkey', o.o_orderkey,
      'custkey', o.o_custkey,
      'orderstatus', o.o_orderstatus,
      'totalprice', o.o_totalprice,
      'orderdate', o.o_orderdate,
      'lineitems', array_agg(
                    object_construct(
                      'linenumber', ln.l_linenumber,
                      'quantity', ln.l_quantity,
                      'status', ln.l_linestatus,
                      'shipdate', ln.l_shipdate,
                      'commitdate', ln.l_commitdate,
                      'receiptdate', ln.l_receiptdate,
                      'extendedprice', ln.l_extendedprice,
                      'discount', ln.l_discount,
                      'tax', ln.l_tax,
                      'part', object_construct(
                                'partkey', p.p_partkey,
                                'name', p.p_name,
                                'manufacturer', p.p_mfgr,
                                'brand', p.p_brand,
                                'type', p.p_type,
                                'size', p.p_size,
                                'container',p.p_container,
                                'retailprice', p.p_retailprice
                              )
                            )
                          )
    )
  FROM sample_data.tpch_sf1.orders o
  INNER JOIN sample_data.tpch_sf1.lineitem ln ON o.o_orderkey = ln.l_orderkey
  INNER JOIN jsample_data.tpch_sf1.part p ON ln.l_partkey = p.p_partkey
  GROUP BY
    o.o_orderkey,
    o.o_custkey,
    o.o_orderstatus,
    o.o_totalprice,
    o.o_orderdate
)
;
