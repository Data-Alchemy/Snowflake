USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_common_db;
USE SCHEMA CORE;

CREATE OR REPLACE FILE FORMAT prd_ent_common_db.core.FF_JSON
  TYPE = JSON
  STRIP_OUTER_ARRAY = TRUE
  STRIP_NULL_VALUES = TRUE
  COMMENT = 'JSON File format with strip_outer_array = true'
;

CREATE OR REPLACE FILE FORMAT prd_ent_common_db.core.FF_CSV
  TYPE = CSV
  ENCODING=UTF8
  FIELD_OPTIONALLY_ENCLOSED_BY = '"'
  SKIP_HEADER = 1
  TRIM_SPACE = TRUE
  COMMENT = 'CSV File format with utf8 encoding and fields optionally enclosed by double quotes'
;
