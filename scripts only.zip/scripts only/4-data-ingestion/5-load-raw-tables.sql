int_stg--create_external_stages.sql
USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_crm_db;

TRUNCATE TABLE prd_ent_crm_db.staging.region_raw;

COPY INTO prd_ent_crm_db.staging.region_raw(
    R_REGIONKEY
  , R_NAME
  , R_COMMENT
)
FROM @prd_ent_common_db.core.int_stg_crm/common
PATTERN = '.*region.*'
ON_ERROR = 'SKIP_FILE'
;

TRUNCATE TABLE prd_ent_crm_db.staging.nation_raw;

COPY INTO prd_ent_crm_db.staging.nation_raw(
    N_NATIONKEY
  , N_NAME
  , N_REGIONKEY
  , N_COMMENT
)
FROM @prd_ent_common_db.core.int_stg_crm/common
PATTERN = '.*nation.*'
;

TRUNCATE TABLE prd_ent_crm_db.staging.customer_raw;

COPY INTO prd_ent_crm_db.staging.customer_raw(
    C_CUSTKEY
  , C_NAME
  , C_ADDRESS
  , C_NATIONKEY
  , C_PHONE
  , C_ACCTBAL
  , C_MKTSEGMENT
  , C_COMMENT )
FROM @prd_ent_common_db.core.int_stg_crm/customers;

USE DATABASE prd_ent_order_source_db;

TRUNCATE TABLE prd_ent_order_source_db.staging.orders_raw;

COPY INTO prd_ent_order_source_db.staging.orders_raw(
    PAYLOAD
  , FILENAME
  , RECORD_NUMBER
)
FROM (
  SELECT
    $1
  , METADATA$FILENAME
  , METADATA$FILE_ROW_NUMBER
  FROM @prd_ent_common_db.core.int_stg_order_source
)
;
