--create_external_stages.sql
USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_common_db;
USE SCHEMA CORE;

PUT file:///Users/rsreenivasan/quickstart/data/crm/customers/customer*.* @prd_ent_common_db.core.int_stg_crm/customers;
PUT file:///Users/rsreenivasan/quickstart/data/crm/common/region*.* @prd_ent_common_db.core.int_stg_crm/common;
PUT file:///Users/rsreenivasan/quickstart/data/crm/common/nation*.* @prd_ent_common_db.core.int_stg_crm/common;
PUT file:///Users/rsreenivasan/quickstart/data/order_source/orders/orders*.* @prd_ent_common_db.core.int_stg_order_source/orders;
