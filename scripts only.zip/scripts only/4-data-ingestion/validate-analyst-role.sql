USE ROLE mktg_analyst_adhoc_role;
USE WAREHOUSE prd_mktg_analyst_whs;

SHOW DATABASES;

-- following query should return result as 0
SELECT
        'Database_Access' as validation_type
    ,   case when count(*) <> 0 then 1 else 0 end as result
FROM table(result_scan(last_query_id()))
WHERE "name" IN ('PRD_ENT_ORDER_SOURCE_DB', 'PRD_ENT_CRM_DB')
;
