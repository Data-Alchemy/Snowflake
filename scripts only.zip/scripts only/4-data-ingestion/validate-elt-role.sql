-- public role should not have access to prd_ent_service_elt_whs. following command should fail
-- Following error is the expected result
-- SQL compilation error: Object does not exist, or operation cannot be performed.
USE ROLE ent_service_elt_role;
USE WAREHOUSE prd_ent_service_elt_whs;

SHOW DATABASES;

-- following query should return result as 0
SELECT
        'Database_Access' as validation_type
    ,   case when count(*) <> array_size(array_construct('PRD_ENT_ORDER_SOURCE_DB', 'PRD_ENT_CRM_DB')) then 1 else 0 end as result
FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
WHERE "name" IN ('PRD_ENT_ORDER_SOURCE_DB', 'PRD_ENT_CRM_DB')
;

-- Following sql statements should not error out
SELECT count(*)
FROM prd_ent_order_source_db.staging.orders_raw;

SELECT count(*)
FROM prd_ent_crm_db.staging.region_raw;

SELECT count(*)
FROM prd_ent_crm_db.staging.nation_raw;

SELECT count(*)
FROM prd_ent_crm_db.staging.customer_raw;

SELECT count(*)
FROM prd_ent_crm_db.common.region;

SELECT count(*)
FROM prd_ent_crm_db.common.nation;

SELECT count(*)
FROM prd_ent_crm_db.customers.customer;

SELECT count(*)
FROM prd_ent_order_source_db.orders.orders;
