USE ROLE SECURITYADMIN;

GRANT SELECT ON ALL TABLES IN SCHEMA prd_ent_order_source_db.orders TO ROLE prd_ent_order_source_db_readonly_role;
GRANT SELECT ON ALL TABLES IN SCHEMA prd_ent_order_source_db.staging TO ROLE prd_ent_order_source_db_readonly_role;
GRANT SELECT ON ALL TABLES IN SCHEMA prd_ent_crm_db.customers TO ROLE prd_ent_crm_db_readonly_role;
GRANT SELECT ON ALL TABLES IN SCHEMA prd_ent_crm_db.common TO ROLE prd_ent_crm_db_readonly_role;
GRANT SELECT ON ALL TABLES IN SCHEMA prd_ent_crm_db.staging TO ROLE prd_ent_crm_db_readonly_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA prd_ent_order_source_db.orders TO ROLE prd_ent_order_source_db_crud_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA prd_ent_order_source_db.staging TO ROLE prd_ent_order_source_db_crud_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA prd_ent_crm_db.customers TO ROLE prd_ent_crm_db_crud_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA prd_ent_crm_db.common TO ROLE prd_ent_crm_db_crud_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA prd_ent_crm_db.staging TO ROLE prd_ent_crm_db_crud_role;
