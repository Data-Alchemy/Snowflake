--create_external_stages.sql
USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_crm_db;

MERGE INTO prd_ent_crm_db.common.region tgt
USING prd_ent_crm_db.staging.region_raw src
ON tgt.r_regionkey = src.r_regionkey
WHEN MATCHED THEN UPDATE SET
    tgt.R_NAME = src.R_NAME
  , tgt.R_COMMENT = src.R_COMMENT
  , tgt.UPDATED_TS = current_timestamp()
  , tgt.UPDATED_BY = 'ETL'
WHEN NOT MATCHED THEN INSERT (
    R_REGIONKEY
  , R_NAME
  , R_COMMENT
) VALUES (
    src.R_REGIONKEY
  , src.R_NAME
  , src.R_COMMENT
);

MERGE INTO prd_ent_crm_db.common.nation tgt
USING prd_ent_crm_db.staging.nation_raw src
ON tgt.n_nationkey = src.n_nationkey
WHEN MATCHED THEN UPDATE SET
    tgt.N_NAME = src.N_NAME
  , tgt.N_REGIONKEY = src.N_REGIONKEY
  , tgt.N_COMMENT = src.N_COMMENT
  , tgt.UPDATED_TS = current_timestamp()
  , tgt.UPDATED_BY = 'ETL'
WHEN NOT MATCHED THEN INSERT (
    N_NATIONKEY
  , N_NAME
  , N_REGIONKEY
  , N_COMMENT
) VALUES (
    src.N_NATIONKEY
  , src.N_NAME
  , src.N_REGIONKEY
  , src.N_COMMENT
);

MERGE INTO prd_ent_crm_db.customers.customer tgt
USING prd_ent_crm_db.staging.customer_raw src
ON tgt.c_custkey = src.c_custkey
WHEN MATCHED THEN UPDATE SET
    tgt.C_NAME = src.C_NAME
  , tgt.C_ADDRESS = src.C_ADDRESS
  , tgt.C_NATIONKEY = src.C_NATIONKEY
  , tgt.C_PHONE = src.C_PHONE
  , tgt.C_ACCTBAL = src.C_ACCTBAL
  , tgt.C_MKTSEGMENT = src.C_MKTSEGMENT
  , tgt.C_COMMENT = src.C_COMMENT
  , tgt.UPDATED_TS = current_timestamp()
  , tgt.UPDATED_BY = 'ETL'
WHEN NOT MATCHED THEN INSERT (
    C_CUSTKEY
  , C_NAME
  , C_ADDRESS
  , C_NATIONKEY
  , C_PHONE
  , C_ACCTBAL
  , C_MKTSEGMENT
  , C_COMMENT
) VALUES (
    src.C_CUSTKEY
  , src.C_NAME
  , src.C_ADDRESS
  , src.C_NATIONKEY
  , src.C_PHONE
  , src.C_ACCTBAL
  , src.C_MKTSEGMENT
  , src.C_COMMENT
);

USE DATABASE prd_ent_order_source_db;

MERGE INTO prd_ent_order_source_db.orders.orders tgt
USING prd_ent_order_source_db.staging.orders_raw src
ON tgt.payload:orderkey::number = src.payload:orderkey::number
AND tgt.filename = src.filename
WHEN MATCHED THEN UPDATE SET
    tgt.RECORD_NUMBER = src.RECORD_NUMBER
  , tgt.UPDATED_TS = current_timestamp()
  , tgt.UPDATED_BY = 'ETL'
WHEN NOT MATCHED THEN INSERT (
    PAYLOAD
  , FILENAME
  , RECORD_NUMBER
) VALUES (
    src.PAYLOAD
  , src.FILENAME
  , src.RECORD_NUMBER
);
