USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_crm_db;

TRUNCATE TABLE prd_ent_crm_db.staging.customer_raw;

-- validate before loading
-- validation_mode = 'RETURN_10_ROWS' validates 10 rows and stops at first error
COPY INTO prd_ent_crm_db.staging.customer_raw
FROM @prd_ent_common_db.public.ext_cust1_crm/customers
VALIDATION_MODE = 'RETURN_10_ROWS'
;

-- Above command failed with the following error due to an extra column in the table
-- Number of columns in file (8) does not match that of the corresponding table (10), use file format option error_on_column_count_mismatch=false to ignore this error
-- if you use error_on_column_count_mismatch = false, default values for extra columns will not be populated.

COPY INTO prd_ent_crm_db.staging.customer_raw
FROM @prd_ent_common_db.public.ext_cust1_crm/customers
FILE_FORMAT = (
  TYPE = CSV
  ENCODING=UTF8
  FIELD_OPTIONALLY_ENCLOSED_BY = '"'
  SKIP_HEADER = 1
  TRIM_SPACE = TRUE
  ERROR_ON_COLUMN_COUNT_MISMATCH = FALSE
);

-- use the following command to validate the results of the previous copy command
SELECT *
FROM TABLE(VALIDATE(prd_ent_crm_db.staging.customer_raw, job_id=>'_last'));
