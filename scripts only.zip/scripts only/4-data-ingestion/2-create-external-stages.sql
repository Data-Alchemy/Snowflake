--create_external_stages.sql
USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_common_db;
USE SCHEMA CORE;
!SET VARIABLE_SUBSTITUTION=TRUE;

CREATE OR REPLACE STAGE prd_ent_common_db.core.ext_stg_crm
URL = 's3://snowflake-data-loading/crm'
CREDENTIALS = (AWS_KEY_ID='&{cust_aws_key_id}' AWS_SECRET_KEY='&{cust_aws_secret}' )
FILE_FORMAT = (FORMAT_NAME = 'PRD_ENT_COMMON_DB.CORE.FF_CSV')
COMMENT = 'external stage location for dimensions import in csv format'
;

CREATE OR REPLACE STAGE prd_ent_common_db.core.ext_stg_order_source
URL = 's3://snowflake-data-loading/order_source'
CREDENTIALS = (AWS_KEY_ID='&{cust_aws_key_id}' AWS_SECRET_KEY='&{cust_aws_secret}')
FILE_FORMAT = (FORMAT_NAME = 'PRD_ENT_COMMON_DB.CORE.FF_JSON')
COMMENT = 'external stage location for customer orders import in json format'
;
