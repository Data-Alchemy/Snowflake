USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_crm_db;

-- when you delete all records, copy_history is not flushed. So, we can use this to test new files
-- however, truncate table flushes copy_history. So, pattern option in copy into command can be used to load only specific files.
-- In this example, we are using TRUNCATE TABLE command.
TRUNCATE TABLE prd_ent_crm_db.staging.region_raw;

-- validate before loading - Try 1 (Failed)
-- validation_mode = 'RETURN_ERRORS'
-- following statement with validation_mode does not work currently in snowflake
-- 002302 (0A000): "SQL Compilation error: Expression 'R_REGIONKEY' not supported within a VALIDATE expression.
COPY INTO prd_ent_crm_db.staging.region_raw(
    R_REGIONKEY
  , R_NAME
  , R_COMMENT
)
FROM @prd_ent_common_db.public.ext_cust1_crm/common
PATTERN = '.*region_2019.*'
VALIDATION_MODE = 'RETURN_ERRORS'
;

-- validate before loading - Try 2 (Failed)
-- validation_mode = 'RETURN_ERRORS'
-- following validation returns all records instead of returning only errors. so, validation does not work correctly with transformation
COPY INTO prd_ent_crm_db.staging.region_raw
FROM (
  SELECT
      $1
    , $2
    , $3
    , CURRENT_USER() || '|' || CURRENT_ROLE()
    , CURRENT_TIMESTAMP
  FROM @prd_ent_common_db.public.ext_cust1_crm/common
)
PATTERN = '.*region_2019.*'
VALIDATION_MODE = 'RETURN_ERRORS'
;

-- validate before loading - Try 3
COPY INTO prd_ent_crm_db.staging.region_raw
FROM @prd_ent_common_db.public.ext_cust1_crm/common
VALIDATION_MODE = 'RETURN_ERRORS';

-- validate before loading - Try 4 (Success)
-- Above command failed with the following error due to an extra column in the table
-- Number of columns in file (3) does not match that of the corresponding table (5), use file format option error_on_column_count_mismatch=false to ignore this error
-- if you use error_on_column_count_mismatch = false, default values for extra columns will not be populated - This is fine for validation mode

TRUNCATE TABLE prd_ent_crm_db.staging.region_raw;

COPY INTO prd_ent_crm_db.staging.region_raw
FROM @prd_ent_common_db.public.ext_cust1_crm/common
FILE_FORMAT = (
  TYPE = CSV
  ENCODING=UTF8
  FIELD_OPTIONALLY_ENCLOSED_BY = '"'
  SKIP_HEADER = 1
  TRIM_SPACE = TRUE
  ERROR_ON_COLUMN_COUNT_MISMATCH = FALSE -- option to bypass extra default columns in the staging table
)
PATTERN = '.*region_2019.*'
VALIDATION_MODE = 'RETURN_ERRORS';

-- validate using on_error = 'CONTINUE' and validate function
COPY INTO prd_ent_crm_db.staging.region_raw(
    R_REGIONKEY
  , R_NAME
  , R_COMMENT
)
FROM @prd_ent_common_db.public.ext_cust1_crm/common
PATTERN = '.*region_2019.*'
ON_ERROR = 'CONTINUE'
;

-- output from the above statement :
/*
+------------------------------------------------------------+------------------+-------------+-------------+-------------+-------------+--------------------------------------+------------------+-----------------------+-------------------------------+
| file                                                       | status           | rows_parsed | rows_loaded | error_limit | errors_seen | first_error                          | first_error_line | first_error_character | first_error_column_name       |
|------------------------------------------------------------+------------------+-------------+-------------+-------------+-------------+--------------------------------------+------------------+-----------------------+-------------------------------|
| s3://snowflake-data-loading/crm/common/region_20190524.csv | PARTIALLY_LOADED |           5 |           4 |           5 |           1 | Numeric value ')2' is not recognized |                4 |                     1 | "REGION_RAW"["R_REGIONKEY":1] |
+------------------------------------------------------------+------------------+-------------+-------------+-------------+-------------+--------------------------------------+------------------+-----------------------+-------------------------------+
*/

-- use the following command to validate the results of the previous copy command
SELECT *
FROM TABLE(VALIDATE(prd_ent_crm_db.staging.region_raw, job_id=>'_last'));

-- output from the above statement :
/*
+--------------------------------------+--------------------------------+------+-----------+-------------+------------+--------+-----------+-------------------------------+------------+----------------+---------------------------------------------+
| ERROR                                | FILE                           | LINE | CHARACTER | BYTE_OFFSET | CATEGORY   |   CODE | SQL_STATE | COLUMN_NAME                   | ROW_NUMBER | ROW_START_LINE | REJECTED_RECORD                             |
|--------------------------------------+--------------------------------+------+-----------+-------------+------------+--------+-----------+-------------------------------+------------+----------------+---------------------------------------------|
| Numeric value ')2' is not recognized | crm/common/region_20190524.csv |    4 |         1 |         210 | conversion | 100038 | 22018     | "REGION_RAW"["R_REGIONKEY":1] |          3 |              4 | )2,"ASIA","ges. thinly even pinto beans ca" |
|                                      |                                |      |           |             |            |        |           |                               |            |                |                                             |
+--------------------------------------+--------------------------------+------+-----------+-------------+------------+--------+-----------+-------------------------------+------------+----------------+---------------------------------------------+
*/
