USE ROLE SECURITYADMIN;

GRANT ROLE ent_developer_role TO USER developer;
GRANT ROLE ent_service_elt_role TO USER service_elt;
GRANT ROLE ent_service_reporting_role TO USER service_reporting;
GRANT ROLE mktg_datascience_adhoc_role TO USER data_scientist;
GRANT ROLE mktg_analyst_adhoc_role TO USER analyst;
