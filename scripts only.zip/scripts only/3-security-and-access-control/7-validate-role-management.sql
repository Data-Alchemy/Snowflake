USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;

SHOW ROLES;
SELECT IFF(val=33,'Success','Failure')
FROM (
SELECT COUNT(*) AS val
FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
WHERE "name"  in (
'ENT_DEVELOPER_ROLE',
'ENT_SERVICE_ELT_ROLE',
'ENT_SERVICE_REPORTING_ROLE',
'MKTG_ANALYST_ADHOC_ROLE',
'MKTG_DATASCIENCE_ADHOC_ROLE',
'PRD_ENT_ORDER_SOURCE_DB_READONLY_ROLE',
'PRD_ENT_CRM_DB_READONLY_ROLE',
'PRD_ENT_INTEGRATION_DB_READONLY_ROLE',
'PRD_ENT_PRESENTATION_DB_READONLY_ROLE',
'DEV_ENT_ORDER_SOURCE_DB_CRUD_ROLE',
'DEV_ENT_CRM_DB_CRUD_ROLE',
'DEV_ENT_INTEGRATION_DB_CRUD_ROLE',
'DEV_ENT_PRESENTATION_DB_CRUD_ROLE',
'DEV_ENT_SERVICE_ELT_WHS_MONITOR_MODIFY_ROLE',
'PRD_ENT_SERVICE_ELT_WHS_USAGE_ROLE',
'PRD_ENT_ORDER_SOURCE_DB_CRUD_ROLE',
'PRD_ENT_CRM_DB_CRUD_ROLE',
'PRD_ENT_INTEGRATION_DB_CRUD_ROLE',
'PRD_ENT_PRESENTATION_DB_CRUD_ROLE',
'PRD_ENT_SERVICE_ELT_WHS_MONITOR_MODIFY_ROLE',
'PRD_ENT_SERVICE_REPORTING_WHS_USAGE_ROLE',
'PRD_MKTG_ANALYST_WHS_USAGE_ROLE',
'PRD_MKTG_DATASCIENCE_WORKSPACE_DB_CRUD_ROLE',
'PRD_MKTG_DATASCIENCE_WHS_MONITOR_MODIFY_ROLE',
'PRD_ENT_SERVICE_REPORTING_WHS_MONITOR_MODIFY_ROLE',
'PRD_MKTG_ANALYST_WHS_MONITOR_MODIFY_ROLE',
'DEV_ENT_ORDER_SOURCE_DB_READONLY_ROLE',
'DEV_ENT_CRM_DB_READONLY_ROLE',
'DEV_ENT_INTEGRATION_DB_READONLY_ROLE',
'DEV_ENT_PRESENTATION_DB_READONLY_ROLE',
'PRD_MKTG_DATASCIENCE_WORKSPACE_DB_READONLY_ROLE',
'DEV_ENT_SERVICE_ELT_WHS_USAGE_ROLE',
'PRD_MKTG_DATASCIENCE_WHS_USAGE_ROLE')
);


SHOW GRANTS TO ROLE ENT_DEVELOPER_ROLE;
SELECT IFF(val=10,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS TO ROLE ent_service_elt_role;
SELECT IFF(val=5,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS TO ROLE ent_service_reporting_role;
SELECT IFF(val=2,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);


SHOW GRANTS TO ROLE mktg_datascience_adhoc_role;
SELECT IFF(val=6,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS TO ROLE mktg_analyst_adhoc_role;
SELECT IFF(val=2,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);


SHOW GRANTS TO USER developer;
SELECT IFF(val='ENT_DEVELOPER_ROLE','Success','Failure') FROM (
SELECT "role" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS TO USER service_elt;
SELECT IFF(val='ENT_SERVICE_ELT_ROLE','Success','Failure') FROM (
SELECT "role" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS TO USER service_reporting;
SELECT IFF(val='ENT_SERVICE_REPORTING_ROLE','Success','Failure') FROM (
SELECT "role" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS TO USER data_scientist;
SELECT IFF(val='MKTG_DATASCIENCE_ADHOC_ROLE','Success','Failure') FROM (
SELECT "role" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS TO USER analyst;
SELECT IFF(val='MKTG_ANALYST_ADHOC_ROLE','Success','Failure') FROM (
SELECT "role" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);


SHOW GRANTS of role prd_ent_order_source_db_readonly_role;
SELECT IFF(val=3,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS of role prd_ent_crm_db_readonly_role;
SELECT IFF(val=3,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS of role prd_ent_integration_db_readonly_role;
SELECT IFF(val=3,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS of role prd_ent_presentation_db_readonly_role;
SELECT IFF(val=5,'Success','Failure') FROM (
SELECT COUNT(*) AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS of role dev_ent_order_source_db_readonly_role;
SELECT IFF(val='DEV_ENT_ORDER_SOURCE_DB_CRUD_ROLE','Success','Failure') FROM (
SELECT "grantee_name" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS of role dev_ent_crm_db_readonly_role;
SELECT IFF(val='DEV_ENT_CRM_DB_CRUD_ROLE','Success','Failure') FROM (
SELECT "grantee_name" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS of role dev_ent_integration_db_readonly_role;
SELECT IFF(val='DEV_ENT_INTEGRATION_DB_CRUD_ROLE','Success','Failure') FROM (
SELECT "grantee_name" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

SHOW GRANTS of role prd_mktg_datascience_workspace_db_readonly_role;
SELECT IFF(val='PRD_MKTG_DATASCIENCE_WORKSPACE_DB_CRUD_ROLE','Success','Failure') FROM (
SELECT "grantee_name" AS val FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
);

--dev_ent_service_elt_whs TO ROLE dev_ent_service_elt_whs_usage_role;
SHOW GRANTS ON WAREHOUSE dev_ent_service_elt_whs;
SELECT IFF(val=1,'Success','Failure') FROM (
  SELECT COUNT(*) AS val
  FROM  TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='DEV_ENT_SERVICE_ELT_WHS_USAGE_ROLE'
    AND "privilege" = 'USAGE'
);


--prd_ent_service_elt_whs TO ROLE prd_ent_service_elt_whs_usage_role;
SHOW GRANTS ON WAREHOUSE prd_ent_service_elt_whs;
SELECT iff(val=1,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='PRD_ENT_SERVICE_ELT_WHS_USAGE_ROLE'
    AND "privilege" = 'USAGE'
);

--prd_ent_service_reporting_whs TO ROLE prd_ent_service_reporting_whs_usage_role;
SHOW GRANTS ON WAREHOUSE prd_ent_service_reporting_whs;
SELECT iff(val=1,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='PRD_ENT_SERVICE_REPORTING_WHS_USAGE_ROLE'
    AND "privilege" = 'USAGE'
);

--prd_mktg_analyst_whs TO ROLE prd_mktg_analyst_whs_usage_role;
SHOW GRANTS ON WAREHOUSE prd_ent_service_reporting_whs;
SELECT iff(val=1,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='PRD_ENT_SERVICE_REPORTING_WHS_USAGE_ROLE'
    AND "privilege" = 'USAGE'
);


--prd_mktg_datascience_whs TO ROLE prd_mktg_datascience_whs_usage_role;
SHOW GRANTS ON WAREHOUSE prd_mktg_datascience_whs;
SELECT iff(val=1,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='PRD_MKTG_DATASCIENCE_WHS_USAGE_ROLE'
    AND "privilege" = 'USAGE'
);


--GRANT MODIFY, MONITOR ON WAREHOUSE dev_ent_service_elt_whs TO ROLE dev_ent_service_elt_whs_monitor_modify_role;
SHOW GRANTS ON WAREHOUSE dev_ent_service_elt_whs;
SELECT iff(val=2,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='DEV_ENT_SERVICE_ELT_WHS_MONITOR_MODIFY_ROLE'
    AND "privilege" IN ('MODIFY', 'MONITOR')
);
--GRANT MODIFY, MONITOR ON WAREHOUSE prd_ent_service_elt_whs TO ROLE prd_ent_service_elt_whs_monitor_modify_role;
SHOW GRANTS ON WAREHOUSE prd_ent_service_elt_whs;
SELECT iff(val=2,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='PRD_ENT_SERVICE_ELT_WHS_MONITOR_MODIFY_ROLE'
    AND "privilege" IN ('MODIFY', 'MONITOR')
);
--GRANT MODIFY, MONITOR ON WAREHOUSE prd_ent_service_reporting_whs TO ROLE prd_ent_service_reporting_whs_monitor_modify_role;
SHOW GRANTS ON WAREHOUSE prd_ent_service_reporting_whs;
SELECT iff(val=2,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='PRD_ENT_SERVICE_REPORTING_WHS_MONITOR_MODIFY_ROLE'
    AND "privilege" IN ('MODIFY', 'MONITOR')
);
--GRANT MODIFY, MONITOR ON WAREHOUSE prd_mktg_analyst_whs TO ROLE prd_mktg_analyst_whs_monitor_modify_role;
SHOW GRANTS ON WAREHOUSE prd_mktg_analyst_whs;
SELECT iff(val=2,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='PRD_MKTG_ANALYST_WHS_MONITOR_MODIFY_ROLE'
    AND "privilege" IN ('MODIFY', 'MONITOR')
);
--GRANT MODIFY, MONITOR ON WAREHOUSE prd_mktg_datascience_whs TO ROLE prd_mktg_datascience_whs_monitor_modify_role;
SHOW GRANTS ON WAREHOUSE prd_mktg_datascience_whs;
SELECT iff(val=2,'Success','Failure') FROM  (
  SELECT COUNT(*) AS val
  FROM   TABLE(RESULT_SCAN(LAST_QUERY_ID()))
  WHERE "grantee_name"='PRD_MKTG_DATASCIENCE_WHS_MONITOR_MODIFY_ROLE'
    AND "privilege" IN ('MODIFY', 'MONITOR')
);
