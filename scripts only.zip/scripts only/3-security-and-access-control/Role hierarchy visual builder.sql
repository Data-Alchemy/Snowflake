with l_role_to_role as
(
    -- all roles that have been granted to another role
    select
         gtr.grantee_name       as parent_id
        ,gtr.name               as child_id
        ,gtr.name               as child_name
        ,gtr.granted_by         as xxx_str
    from
        snowflake.account_usage.grants_to_roles gtr
    where
            privilege       = 'USAGE'
        and granted_on      = 'ROLE'
        and granted_to      = 'ROLE'
        and deleted_on     is null
)
,l_parent_child as
(
    -- force system roles to have their own hierarchies
    select
         ar.$1  as parent_id
        ,ar.$2  as child_id
        ,ar.$3  as child_name
        ,ar.$4  as xxx_str
    from
        (values
             ( to_char( null ), 'ACCOUNTADMIN',  'ACCOUNTADMIN',  'ACCOUNTADMIN' )
            ,( to_char( null ), 'SECURITYADMIN', 'SECURITYADMIN', 'ACCOUNTADMIN' )
            ,( to_char( null ), 'SYSADMIN',      'SYSADMIN',      'ACCOUNTADMIN' )
        ) ar
    union
    -- pull all other roles that have not be granted to any other role
    select
         to_char( null )    as parent_id
        ,r.name             as child_id
        ,r.name             as child_name
        ,'xxx'              as xxx_str
    from
        snowflake.account_usage.roles r
    where
            r.deleted_on is null
        and r.name not in ( select child_name from l_role_to_role )
    union
    -- all roles granted to other roles
    select
         parent_id
        ,child_id
        ,child_name
        ,xxx_str
    from
        l_role_to_role
)
select
     root_parent_id                                     as l1_id
    ,level_no
    ,'`' || repeat( '------', level_no - 1 ) || to_char( child_id )             as hierarchy_level
    -- flag path that is at the lowest level of the hierarchy
    ,case
        when level_no < lead( level_no ) over( partition by root_parent_id order by child_path_str )
        then 0
        else 1
     end                                                as leaf_bt
    -- parse out last defined path in the nodes hierarchy
    ,xxx_str                                            as node_xxx_str
    ,split_part( trim( xxx_str, '|' ), '|', -1 )        as assigned_xxx_str
    -- parse out nodes in hiearchy that follow the root
    ,split_part( child_path_str, '|', 2 )               as l2_id
    ,split_part( child_path_str, '|', 3 )               as l3_id
    ,split_part( child_path_str, '|', 4 )               as l4_id
    ,split_part( child_path_str, '|', 5 )               as l5_id
    ,split_part( child_path_str, '|', 6 )               as l6_id
    ,split_part( child_path_str, '|', 7 )               as l7_id
    ,split_part( child_path_str, '|', 8 )               as l8_id
    ,split_part( child_path_str, '|', 9 )               as l9_id
    ,child_path_str
    ,xxx_path_str
from
    (
    --
    -- use connect by to establish hierarchy paths
    --
    select
         connect_by_root child_name                             as root_parent_name
        ,connect_by_root child_id                               as root_parent_id
        ,parent_id
        ,child_id
        ,child_name
        ,xxx_str
        ,level                                                  as level_no
        ,sys_connect_by_path( ifnull( xxx_str, '' ), '|' )      as xxx_path_str
        ,sys_connect_by_path( to_char( child_id ), '|' )        as child_path_str
    from
        l_parent_child lpc
    start with
        parent_id is null
    connect by
        parent_id = prior child_id
    ) a
order by
    child_path_str
;