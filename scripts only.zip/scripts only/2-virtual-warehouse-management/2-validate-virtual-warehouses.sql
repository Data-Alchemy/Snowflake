-- Login as user adminuser.

--VALIDATE that all Warehouses have been created:

SHOW WAREHOUSES LIKE 'dev_ent_%';
SHOW WAREHOUSES LIKE 'prd_ent_%';
SHOW WAREHOUSES LIKE 'prd_mktg_%';

--end of script