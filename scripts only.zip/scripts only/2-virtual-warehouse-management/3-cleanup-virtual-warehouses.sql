-- Login as user adminuser.

--CLEAN UP SCRIPT


DROP WAREHOUSE IF EXISTS  "dev_ent_service_elt_whs";

DROP WAREHOUSE IF EXISTS  "prd_ent_service_elt_whs";

DROP WAREHOUSE IF EXISTS  "prd_ent_service_reporting_whs";

DROP WAREHOUSE IF EXISTS  "prd_mktg_analyst_adhoc_whs";

DROP WAREHOUSE IF EXISTS  "prd_mktg_analyst_whs";

DROP WAREHOUSE IF EXISTS  "prd_mktg_datascience_adhoc_whs";

DROP WAREHOUSE IF EXISTS  "prd_ent_datascience_whs";

DROP WAREHOUSE IF EXISTS  "prd_mktg_datascience_whs";

--end of script