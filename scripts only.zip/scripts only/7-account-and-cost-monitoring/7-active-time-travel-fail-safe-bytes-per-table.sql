/* ACTIVE BYTES, TIME TRAVEL BYTES and FAIL-SAFE BYTES PER TABLE*/
USE ROLE ACCOUNTADMIN;
USE WAREHOUSE prd_mktg_analyst_adhoc_whs;
USE DATABASE dev_ent_integration_db;
SELECT * 
FROM information_schema.table_storage_metrics
WHERE table_created>= DATEADD('DAYS',-30,CURRENT_DATE());
