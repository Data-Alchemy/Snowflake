/*Total credits used along with dollar amount per day */
USE ROLE ACCOUNTADMIN;
Use WAREHOUSE prd_mktg_analyst_adhoc_whs;

SET compute_price=2.50;
SELECT DATE_TRUNC(month, start_time) AS usage_month
     , SUM(COALESCE(credits_used, 0.00)) AS total_credits
     , SUM($compute_price * COALESCE(credits_used, 0.00)) AS billable_warehouse_usage
FROM snowflake.account_usage.warehouse_metering_history
WHERE start_time >= DATE_TRUNC(month, DATEADD(MONTH,-3,CURRENT_TIMESTAMP))
AND start_time < DATE_TRUNC(month, CURRENT_TIMESTAMP)
GROUP BY  usage_month;
