/*Data transfer history for the past 6 months*/
USE ROLE ACCOUNTADMIN; 
USE WAREHOUSE prd_mktg_analyst_adhoc_whs;
SELECT * FROM
snowflake.account_usage.data_transfer_history
WHERE end_time >= DATEADD('MONTH',-6,CURRENT_TIMESTAMP());
