/*Data transfer history for the last 14 days*/
USE ROLE SYSADMIN;
USE WAREHOUSE prd_mktg_analyst_adhoc_whs;
USE DATABASE dev_ent_integration_db;
SELECT *
  FROM TABLE(information_schema.data_transfer_history(
    date_range_start=>dateadd('day',-14,current_date()),
    date_range_end=>current_date()));

