/*Following is an example of total credits consumed per warehouse in the past 30 days*/
USE ROLE SYSADMIN; 
Use WAREHOUSE prd_mktg_analyst_adhoc_whs;
USE DATABASE dev_ent_integration_db;

SELECT  MIN(start_time)
      , MAX(end_time)
      , warehouse_name
      , SUM(credits_used)
FROM TABLE(INFORMATION_SCHEMA.WAREHOUSE_METERING_HISTORY(DATEADD('DAYS',-30,CURRENT_DATE())))
GROUP BY warehouse_name;
