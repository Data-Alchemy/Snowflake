/* The following script gives us the total number of bytes used per storage, stage and failsafe (bytes) */
USE ROLE ACCOUNTADMIN;
Use WAREHOUSE prd_mktg_analyst_adhoc_whs;
SELECT *
FROM snowflake.account_usage.storage_usage
WHERE usage_date >= DATEADD('DAYS',-7,CURRENT_DATE())
ORDER BY usage_date;
