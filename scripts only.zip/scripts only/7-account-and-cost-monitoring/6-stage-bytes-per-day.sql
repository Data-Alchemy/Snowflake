/* STAGE BYTES BREAKDOWN BY DAY */
USE ROLE SYSADMIN; 
USE WAREHOUSE prd_mktg_analyst_adhoc_whs;
USE DATABASE dev_ent_integration_db;
SELECT *
FROM TABLE(information_schema.stage_storage_usage_history(
    DATE_RANGE_START=>'2019-2-01',
    DATE_RANGE_END=>current_date()));
