-- Login as adminuser
-- Create database for each environment and database layer
--  Development: for development, data_retention_time_in_days is left blank intentionally.

  USE ROLE SYSADMIN;
  -- create dev databases for each data source: source1, source2 etc.,
  CREATE DATABASE dev_ent_order_source_db COMMENT = 'Development db for source1';
  CREATE DATABASE dev_ent_crm_db COMMENT = 'Development db for source2';
  -- create dev databases for integration layer
  CREATE DATABASE dev_ent_integration_db COMMENT = 'Development db for integration layer';
  -- create dev database for presentation layer
  CREATE DATABASE dev_ent_presentation_db COMMENT = 'Development db for presentation layer';
  -- create dev database for outbound layer
  CREATE DATABASE dev_ent_outbound_db COMMENT = 'Development db for outbound layer';
  -- create dev database to store file formats, stages and other common objects
  CREATE DATABASE dev_ent_common_db COMMENT = 'Development db for common file formats, stages etc.,';

-- Production: data_retention_time_in_days is left blank intentionally
-- create prod databases for each data source: source1, source2 etc.,
  CREATE DATABASE prd_ent_order_source_db COMMENT = 'Production db for source1';
  CREATE DATABASE prd_ent_crm_db COMMENT = 'Production db for source2';
  -- create prod databases for integration layer
  CREATE DATABASE prd_ent_integration_db COMMENT = 'Production db for integration layer';
  -- create prod database for presentation layer
  CREATE DATABASE prd_ent_presentation_db COMMENT = 'Production db for presentation layer';
  -- create prod database for outbound layer
  CREATE DATABASE prd_ent_outbound_db COMMENT = 'Production db for outbound layer';
  -- create prod database for marketing data science workspace
  CREATE DATABASE prd_mktg_datascience_workspace_db COMMENT = 'Production db for Marketing Data Science Team';
  -- create prod database to store file formats, stages and other common objects
  CREATE DATABASE prd_ent_common_db COMMENT = 'Development db for common file formats, stages etc.,';

-- Development: Create raw, integration and presentation schemas:
-- notes: if customer prefers to use managed access to delegate grant operations to schema
--  owner, then with managed access option can be specified while creating the schema

  USE DATABASE dev_ent_order_source_db;
  CREATE OR REPLACE SCHEMA staging COMMENT='Dev schema to store all the raw tables from the source';
  CREATE OR REPLACE SCHEMA orders COMMENT='Dev schema to store all the flattened views and tables from the source';

  USE DATABASE dev_ent_crm_db;
  CREATE OR REPLACE SCHEMA staging COMMENT='Dev schema to store all the raw tables from the source';
  CREATE OR REPLACE SCHEMA customers COMMENT='Dev schema to store customers data from the source';
  CREATE OR REPLACE SCHEMA common COMMENT='Dev schema to store common dimensional data from the source';

  USE DATABASE dev_ent_integration_db;
  CREATE SCHEMA utility COMMENT='Dev schema to store UDFS, Stored procedures';
  CREATE SCHEMA derived COMMENT='Dev schema to store tables derived from other tables';

  USE DATABASE dev_ent_presentation_db;
  CREATE SCHEMA dimensions COMMENT='Dev schema to store common dimensions';
  CREATE SCHEMA marketing COMMENT='Dev schema to store marketing related tables';
  CREATE SCHEMA sales COMMENT='Dev schema to store sales related tables';

  USE DATABASE dev_ent_outbound_db;
  CREATE SCHEMA core COMMENT='Dev schema to store outbound objects such as shareable objects';

  USE DATABASE dev_ent_common_db;
  CREATE SCHEMA core COMMENT='Dev schema to store common objects';

-- Production: Create raw, integration and presentation schemas:
-- notes: if customer prefers to use managed access to delegate grant operations to schema owner
--  with managed access option can be specified while creating the schema or at a later point

  USE DATABASE prd_ent_order_source_db;
  CREATE OR REPLACE SCHEMA staging COMMENT='Prod schema to store all the raw tables from the source';
  CREATE OR REPLACE SCHEMA orders COMMENT='Prod schema to store all the flattened views and tables from the source';

  USE DATABASE prd_ent_crm_db;
  CREATE OR REPLACE SCHEMA staging COMMENT='Prod schema to store all the raw tables from the source';
  CREATE OR REPLACE SCHEMA customers COMMENT='Prod schema to store customers data from the source';
  CREATE OR REPLACE SCHEMA common COMMENT='Prod schema to store common dimensional data from the source';

  USE DATABASE prd_ent_integration_db;
  CREATE SCHEMA utility COMMENT='Prod schema to store UDFS, Stored procedures';
  CREATE SCHEMA derived COMMENT='Prod schema to store tables derived from other tables';

  USE DATABASE prd_ent_presentation_db;
  CREATE SCHEMA dimensions COMMENT='Prod schema to store common dimensions';
  CREATE SCHEMA marketing COMMENT='Prod schema to store marketing related tables';
  CREATE SCHEMA sales COMMENT='Prod schema to store sales related tables';

  USE DATABASE prd_ent_outbound_db;
  CREATE SCHEMA core COMMENT='Prod schema to store outbound objects such as shareable objects';

  USE DATABASE prd_ent_common_db;
  CREATE SCHEMA core COMMENT='Prod schema to store common objects';

  USE DATABASE prd_mktg_datascience_workspace_db;
  -- create work schema rs_work for user with initials rs
  -- repeat this for each user who needs a work area
  CREATE SCHEMA rs_work COMMENT='work area for data scientist with initials rs';
