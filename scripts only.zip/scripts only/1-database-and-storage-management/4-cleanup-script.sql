-- clean up
USE ROLE SYSADMIN;
DROP DATABASE IF EXISTS dev_ent_order_source_db;
DROP DATABASE IF EXISTS dev_ent_crm_db;
DROP DATABASE IF EXISTS dev_ent_integration_db;
DROP DATABASE IF EXISTS dev_ent_presentation_db;
DROP DATABASE IF EXISTS dev_ent_outbound_db;
DROP DATABASE IF EXISTS dev_ent_common_db;
DROP DATABASE IF EXISTS prd_ent_order_source_db;
DROP DATABASE IF EXISTS prd_ent_crm_db;
DROP DATABASE IF EXISTS prd_ent_integration_db;
DROP DATABASE IF EXISTS prd_ent_presentation_db;
DROP DATABASE IF EXISTS prd_ent_outbound_db;
DROP DATABASE IF EXISTS prd_mktg_datascience_workspace_db;
DROP DATABASE IF EXISTS prd_ent_common_db;

USE ROLE SECURITYADMIN;
DROP USER IF EXISTS adminuser;
