-- Best practice: Use the comment option while creating objects
-- Create adminuser user
  USE ROLE SECURITYADMIN;
  CREATE USER adminuser
    PASSWORD = 'Passw0rd1!'
    DEFAULT_ROLE = SYSADMIN
    MUST_CHANGE_PASSWORD = true
    COMMENT = 'Super DBA User';

-- Add adminuser to SYSADMIN & SECURITYADMIN roles.
  USE ROLE SECURITYADMIN;
  GRANT ROLE SECURITYADMIN TO USER adminuser;
  GRANT ROLE SYSADMIN TO USER adminuser;
