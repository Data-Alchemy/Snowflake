/* integrations */

-- combine nation and region into new table
-- table name: location

create table location
select *
from nation join region

Solution: scripts/1_Transform_location.sql


-- flatten / parse the parts from orders / line item tables
-- table name parts

select *
from flatten(customer_orders, parts)


-- flatten / parse the order details from orders / line item tables
-- table name order_details

/* derivations in order_details

select o.*, n.*, 
    l_extendedprice / l_quantity as unit_price
,(l_extendedprice - (l_extendedprice * l_discount)) * l_tax as tax_amt
from customer_orders o, flatten(customer_orders, line_items) n



*/
Solution: scripts/2_Transform_OrderDetails.sql

/* utilities used with creation of order_details table

- UDF could be used for derived values so it can check for divide by zero error.
- Stored procedure could simply repeat the same load script as a sproc.
- Materialized view could repeat load as an MV
- Cluster key could also repeat same scenario with clustering on l_receiptdate

*/

UDF Solution:   scripts/3_divide_by_zero_check.sql
            scripts/4_sp_load_order_details.sql
            

Execute these scripts in prd_ent_integration_db and schema derived context.  Then, urn the following

TRUNCATE TABLE prd_ent_integration_db.derived.order_details;

CALL sp_load_order_details('prd_ent_integration_db','derived');

Materialized View Solution:  scripts/5_create_materialized_view.sql

Clustered Materialized View Solution:  scripts/6_create_clustered_materialized_view.sql

View the clustering statistics with this sql:

SELECT SYSTEM$CLUSTERING_INFORMATION 
   ( 'mv_order_details_clustered' , '(receipt_date)' );

/* presentation */
--load into dimensions schema: dim_location
-- derived.location with surrogate key, etc

--load into customer_orders datamart schema: dim_parts, dim_orders, fact_order_price
-- dim_parts = derived.parts with surrogate key, etc
-- dim_orders = derived.order_details without unit_price, tax_amt with surrogate key, etc
-- fact_order_price = derived.order_details unit_price, tax_amount with dim keys

Solution:  scripts/7_load_sales_dims_and_fact.sql

/* queries */

-- write queries to show usage of dims/fact
--price + tax per customer
--price + tax by region
--total orders by nation, region

Solution:  scripts/8_queries.sql
