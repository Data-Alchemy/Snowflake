
USE ROLE SYSADMIN;

USE DATABASE prd_ent_integration_db;
USE SCHEMA utility;

USE WAREHOUSE prd_ent_service_elt_whs;

CREATE FUNCTION divide_by_zero_check(NUMERATOR FLOAT, DENOMINATOR FLOAT)
  returns FLOAT
  as
  $$
    CASE WHEN DENOMINATOR = 0 THEN 0
    ELSE NUMERATOR/DENOMINATOR END
  $$
  ;


GRANT USAGE ON FUNCTION prd_ent_integration_db.utility.divide_by_zero_check(FLOAT,FLOAT) TO ROLE ent_service_elt_role;