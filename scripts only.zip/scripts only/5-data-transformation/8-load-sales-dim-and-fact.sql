USE ROLE SYSADMIN;
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_presentation_db;
USE SCHEMA sales;

CREATE OR REPLACE sequence seq_part start = 1 increment = 1;

CREATE OR REPLACE TABLE dim_parts
(
  part_id INTEGER DEFAULT seq_part.nextval,
  part_key INTEGER,
  name VARCHAR(200),
  manufacturer VARCHAR(200),
  brand VARCHAR(100),
  type VARCHAR(100),
  size INTEGER,
  container VARCHAR(100),
  retail_price DECIMAL(12,2)
);

INSERT OVERWRITE INTO sales.dim_parts (part_key, brand, manufacturer, container, name, retail_price, type, size)
SELECT DISTINCT
    li.value:part:partkey AS part_key,
    li.value:part:brand AS brand,
    li.value:part:manufacturer AS manufacturer,
    li.value:part:container AS container,
    li.value:part:name AS name,
    li.value:part:retailprice AS retail_price,
    li.value:part:type AS type,
    li.value:part:size AS size
FROM  prd_ent_order_source_db.orders.orders co,
LATERAL FLATTEN(INPUT => co.payload, PATH => 'lineitems') li;


USE DATABASE prd_ent_presentation_db;
USE SCHEMA dimensions;

CREATE OR REPLACE sequence seq_location start = 1 increment = 1;

CREATE TABLE dim_location
(
location_id INTEGER DEFAULT seq_location.nextval,
nation_key INTEGER,
country_name VARCHAR(100),
country_comment VARCHAR(200),
region_key INTEGER,
region_name VARCHAR(100),
region_comment VARCHAR(200)
);


INSERT INTO dim_location(nation_key, country_name, country_comment, region_key, region_name, region_comment)
SELECT n.n_nationkey,
n.n_name,
n.n_comment,
r.r_regionkey,
r.r_name,
r.r_comment
FROM prd_ent_crm_db.common.nation n
INNER JOIN prd_ent_crm_db.common.region r
ON r.r_regionkey = n.n_regionkey;

USE SCHEMA sales;

CREATE OR REPLACE SEQUENCE seq_dim_orders start = 1 increment = 1;

CREATE or replace TABLE dim_orders (
  order_line_id INTEGER DEFAULT seq_dim_orders.nextval,
  customer_key INTEGER,
  order_key INTEGER,
  order_status VARCHAR(20),
  total_price  DECIMAL(12,2),
  order_date DATE,
  line_number INTEGER,
  quantity INTEGER,
  line_status VARCHAR(20),
  ship_date DATE,
  commit_date DATE,
  receipt_date DATE,
  extended_price DECIMAL(12,2),
  discount DECIMAL(6,4),
  tax DECIMAL(6,4)
  );

INSERT OVERWRITE INTO dim_orders
(customer_key, order_key, order_status, total_price, order_date, line_number, quantity, line_status, ship_date, commit_date, receipt_date, extended_price, discount, tax)
SELECT
    co.payload:custkey::INTEGER AS customer_key,
    co.payload:orderkey::INTEGER AS order_key,
    co.payload:orderstatus::VARCHAR(20) AS order_status,
    co.payload:totalprice::DECIMAL(12,2) AS total_price,
    co.payload:orderdate::DATE AS order_date,
    li.value:linenumber::INTEGER AS line_number,
    li.value:quantity::INTEGER AS quantity,
    li.value:status::VARCHAR(20) as line_status,
    li.value:shipdate::DATE AS ship_date,
    li.value:commitdate::DATE AS commit_date,
    li.value:receiptdate::DATE AS receipt_date,
    li.value:extendedprice::DECIMAL(12,2) AS extended_price,
    li.value:discount::DECIMAL(6,4) AS discount,
    li.value:tax::DECIMAL(6,4) AS tax
FROM  prd_ent_order_source_db.orders.orders co,
LATERAL FLATTEN(INPUT => co.payload, PATH => 'lineitems') li
;

CREATE OR REPLACE SEQUENCE seq_customer START=1 INCREMENT=1;

CREATE OR REPLACE TABLE dim_customer (
  customer_id INTEGER DEFAULT seq_customer.nextval,
  customer_key INTEGER,
  name VARCHAR(200),
  address VARCHAR(2000),
  location_id INTEGER,
  phone VARCHAR(200),
  account_balance NUMBER(38,6),
  market_segment VARCHAR(200)
);

INSERT OVERWRITE INTO dim_customer (customer_key, name, address, location_id, phone, account_balance, market_segment)
SELECT c_custkey AS customer_key,
  c_name AS name,
  c_address AS address,
  l.location_id AS location_id,
  c_phone AS phone,
  c_acctbal AS account_balance,
  c_mktsegment AS market_segment
FROM prd_ent_crm_db.customers.customer c
INNER JOIN prd_ent_presentation_db.dimensions.dim_location l
  on c.c_nationkey = l.nation_key;


CREATE OR REPLACE TABLE fact_order_price (
  customer_id INTEGER,
  order_line_id INTEGER,
  part_id INTEGER,
  quantity INTEGER,
  unit_price NUMBER(14,2),
  tax_amt NUMBER(14,2)
);

INSERT OVERWRITE INTO fact_order_price (customer_id, order_line_id, quantity, part_id, unit_price, tax_amt)
SELECT
   c.customer_id,
   dol.order_line_id,
   dol.quantity,
   dp.part_id,
   dol.extended_price / dol.quantity AS unit_price,
   (dol.extended_price - (dol.extended_price * dol.discount)) * dol.tax AS tax_amt
FROM (
SELECT
    co.payload:custkey::INTEGER AS customer_key,
    co.payload:orderkey::INTEGER AS order_key,
    li.value:linenumber::INTEGER AS line_number,
    li.value:part:partkey::INTEGER AS part_key
FROM  prd_ent_order_source_db.orders.orders co,
LATERAL FLATTEN(INPUT => co.payload, PATH => 'lineitems') li
) li
INNER JOIN sales.dim_orders dol
ON dol.order_key = li.order_key
   AND dol.line_number = li.line_number
INNER JOIN sales.dim_parts dp
ON dp.part_key = li.part_key
INNER JOIN dim_customer c
ON c.customer_key = dol.customer_key;

GRANT SELECT ON ALL TABLES IN SCHEMA prd_ent_presentation_db.sales TO ROLE prd_ent_presentation_db_readonly_role;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA prd_ent_presentation_db.sales TO ROLE prd_ent_presentation_db_crud_role;
