
USE DATABASE prd_ent_integration_db;
USE SCHEMA derived;

USE WAREHOUSE prd_ent_service_elt_whs;

CREATE OR REPLACE TABLE prd_ent_integration_db.derived.order_details(
  customer_key INTEGER,
  order_key INTEGER,
  order_status VARCHAR(20),
  total_price DECIMAL(12,2),
  order_date DATE,
  line_number INTEGER,
  commit_date DATE,
  brand VARCHAR(100),
  manufacturer VARCHAR(200),
  container VARCHAR(100),
  name VARCHAR(200),
  part_key INTEGER,
  retail_price DECIMAL(12,2),
  type VARCHAR(100),
  size INTEGER,
  extended_price DECIMAL(12,2),
  quantity INTEGER,
  tax DECIMAL(6,4),
  discount DECIMAL(6,4),
  unit_price DECIMAL(12,2),
  tax_amt DECIMAL(12,2)
  );

INSERT OVERWRITE INTO prd_ent_integration_db.derived.order_details 
  (customer_key, order_key, order_status, total_price, order_date, line_number, commit_date, brand, manufacturer, container, name, part_key, retail_price, type, size, extended_price, quantity,tax, discount, unit_price, tax_amt)
SELECT 
    co.payload:custkey::INTEGER AS customer_key,
    co.payload:orderkey::INTEGER AS order_key,
    co.payload:orderstatus::VARCHAR(20) AS order_status,
    co.payload:totalprice::DECIMAL(12,2) AS total_price,
    co.payload:orderdate::DATE AS order_date,
    li.value:linenumber::INTEGER as line_number,
    li.value:commitdate::DATE AS commit_date,
    li.value:part:brand::VARCHAR(100) AS brand,
    li.value:part:manufacturer::VARCHAR(200) AS manufacturer,
    li.value:part:container::VARCHAR(100) AS container,
    li.value:part:name::VARCHAR(200) AS name,
    li.value:part:partkey::INTEGER AS part_key,
    li.value:part:retailprice::DECIMAL(12,2) AS retail_price,
    li.value:part:type::VARCHAR(100) AS type,
    li.value:part:size::INTEGER AS size,
    li.value:extendedprice::DECIMAL(12,2) as extended_price,
    li.value:quantity::INTEGER AS quantity,
    li.value:tax::DECIMAL(6,4) AS tax,
    li.value:discount::DECIMAL(6,4) AS discount,
    li.value:extendedprice::DECIMAL(12,2) / li.value:quantity::INTEGER AS unit_price,
    (li.value:extendedprice::DECIMAL(12,2) - (li.value:extendedprice::DECIMAL(12,2) * li.value:discount::DECIMAL(6,4))) * li.value:tax::DECIMAL(6,4) AS tax_amt
FROM   prd_ent_order_source_db.orders.orders co,
LATERAL FLATTEN(INPUT => co.payload, PATH => 'lineitems') li;


GRANT SELECT ON ALL TABLES IN SCHEMA prd_ent_integration_db.derived TO ROLE prd_ent_integration_db_readonly_role;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA prd_ent_integration_db.derived TO ROLE prd_ent_integration_db_crud_role;
