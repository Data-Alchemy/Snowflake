
USE ROLE SYSADMIN;
USE DATABASE prd_ent_integration_db;
USE WAREHOUSE prd_ent_service_elt_whs;

--prd_ent_integration_db.derived.location

SELECT IFF(val=6,'Success','Failure') FROM (
SELECT COUNT(*) AS val 
FROM prd_ent_integration_db.information_schema.columns
WHERE LOWER(table_name)='location' 
AND LOWER(table_catalog)='prd_ent_integration_db' 
AND LOWER(table_schema) = 'derived');

SELECT IFF(val>0, 'Success', 'Failure') FROM (
SELECT COUNT(*)  AS val
FROM prd_ent_integration_db.derived.location);


--prd_ent_integration_db.derived.order_details


SELECT IFF(val=21,'Success','Failure') FROM (
SELECT COUNT(*) AS val 
FROM prd_ent_integration_db.information_schema.columns
WHERE LOWER(table_name)='order_details' 
AND LOWER(table_catalog)='prd_ent_integration_db' 
AND LOWER(table_schema) = 'derived');

SELECT IFF(val>0, 'Success', 'Failure') FROM (
SELECT COUNT(*)  AS val
FROM prd_ent_integration_db.derived.order_details);



--prd_ent_presentation_db.sales.dim_parts

use database prd_ent_presentation_db;

SELECT IFF(val=9,'Success','Failure') FROM (
SELECT COUNT(*) AS val 
FROM information_schema.columns
WHERE LOWER(table_name)='dim_parts' 
AND LOWER(table_catalog)='prd_ent_presentation_db' 
AND LOWER(table_schema) = 'sales');

SELECT IFF(val>0, 'Success', 'Failure') FROM (
SELECT COUNT(*)  AS val
FROM prd_ent_presentation_db.sales.dim_parts);

--prd_ent_presentation_db.dimensions.dim_location

SELECT IFF(val=7,'Success','Failure') FROM (
SELECT COUNT(*) AS val 
FROM information_schema.columns
WHERE LOWER(table_name)='dim_location' 
AND LOWER(table_catalog)='prd_ent_presentation_db' 
AND LOWER(table_schema) = 'dimensions');

SELECT IFF(val>0, 'Success', 'Failure') FROM (
SELECT COUNT(*)  AS val
FROM prd_ent_presentation_db.dimensions.dim_location);

--prd_ent_presentation_db.sales.dim_orders

SELECT IFF(val=15,'Success','Failure') FROM (
SELECT COUNT(*) AS val 
FROM information_schema.columns
WHERE LOWER(table_name)='dim_orders' 
AND LOWER(table_catalog)='prd_ent_presentation_db' 
AND LOWER(table_schema) = 'sales');

SELECT IFF(val>0, 'Success', 'Failure') FROM (
SELECT COUNT(*)  AS val
FROM prd_ent_presentation_db.sales.dim_orders);

--prd_ent_presentation_db.sales.dim_customer

SELECT IFF(val=15,'Success','Failure') FROM (
SELECT COUNT(*) AS val 
FROM prd_ent_presentation_db.information_schema.columns
WHERE LOWER(table_name)='dim_orders' 
AND LOWER(table_catalog)='prd_ent_presentation_db' 
AND LOWER(table_schema) = 'sales');

SELECT IFF(val>0, 'Success', 'Failure') FROM (
SELECT COUNT(*)  AS val
FROM prd_ent_presentation_db.sales.dim_orders);

--prd_ent_presentation_db.sales.fact_order_price

SELECT IFF(val=6,'Success','Failure') FROM (
SELECT COUNT(*) AS val 
FROM information_schema.columns
WHERE LOWER(table_name)='fact_order_price' 
AND LOWER(table_catalog)='prd_ent_presentation_db' 
AND LOWER(table_schema) = 'sales');

SELECT IFF(val>0, 'Success', 'Failure') FROM (
SELECT COUNT(*)  AS val
FROM prd_ent_presentation_db.sales.fact_order_price);
