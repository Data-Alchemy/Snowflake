USE ROLE SYSADMIN;

USE DATABASE prd_ent_integration_db;
USE SCHEMA utility;

USE WAREHOUSE prd_ent_service_elt_whs;

CREATE OR REPLACE PROCEDURE sp_load_order_details(db_name VARCHAR, schema_name VARCHAR)
    RETURNS STRING
    LANGUAGE javascript
    AS
    $$
  var sql_command = "INSERT INTO "+DB_NAME+"."+SCHEMA_NAME+".order_details \
  (customer_key, order_key, order_status, total_price, order_date, line_number, commit_date, brand, manufacturer, container, name, part_key, retail_price, type, size, extended_price, quantity,tax, discount, unit_price, tax_amt) \
    SELECT \
      co.payload:custkey::INTEGER AS customer_key,\
      co.payload:orderkey::INTEGER AS order_key,\
      co.payload:orderstatus::VARCHAR(20) AS order_status,\
      co.payload:totalprice::DECIMAL(12,2) AS total_price,\
      co.payload:orderdate::DATE AS order_date,\
      li.value:linenumber::INTEGER as line_number,\
      li.value:commitdate::DATE AS commit_date,\
      li.value:part:brand::VARCHAR(100) AS brand,\
      li.value:part:manufacturer::VARCHAR(200) AS manufacturer,\
      li.value:part:container::VARCHAR(100) AS container,\
      li.value:part:name::VARCHAR(200) AS name,\
      li.value:part:partkey::INTEGER AS part_key,\
      li.value:part:retailprice::DECIMAL(12,2) AS retail_price,\
      li.value:part:type::VARCHAR(100) AS type,\
      li.value:part:size::INTEGER AS size,\
      li.value:extendedprice::DECIMAL(12,2) as extended_price,\
      li.value:quantity::INTEGER AS quantity,\
      li.value:tax::DECIMAL(6,4) AS tax,\
      li.value:discount::DECIMAL(6,4) AS discount,\
      divide_by_zero_check(li.value:extendedprice::DECIMAL(12,2), li.value:quantity::INTEGER) AS unit_price,\
      li.value:extendedprice::DECIMAL(12,2) - (li.value:extendedprice::DECIMAL(12,2) * li.value:discount::DECIMAL(6,4)) * li.value:tax::DECIMAL(6,4) AS tax_amt\
    FROM prd_ent_order_source_db.orders.orders co,\
    LATERAL FLATTEN(INPUT => co.payload, PATH => 'lineitems') li;";
    //return(sql_command)


   try {
        snowflake.execute (
            {sqlText: sql_command}
            );
        return "Succeeded.";   // Return a success/error indicator.
        }
    catch (err)  {
        return "Failed: " + err;   // Return a success/error indicator.
        }

    $$
    ;

    GRANT USAGE ON PROCEDURE prd_ent_integration_db.utility.sp_load_order_details(VARCHAR,VARCHAR) TO ROLE ent_service_elt_role;
