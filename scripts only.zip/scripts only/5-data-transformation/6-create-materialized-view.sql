USE ROLE SYSADMIN;
USE DATABASE prd_ent_integration_db;
USE SCHEMA derived;

CREATE MATERIALIZED VIEW mv_order_details AS 
SELECT 
    co.payload:custkey::INTEGER AS customer_key,
    co.payload:orderkey::INTEGER AS order_key,
    co.payload:orderstatus::VARCHAR(20) AS order_status,
    co.payload:totalprice::DECIMAL(12,2) AS total_price,
    co.payload:orderdate::DATE AS order_date,
    li.value:linenumber::INTEGER as line_number,
    li.value:commitdate::DATE AS commit_date,
    li.value:part:brand::VARCHAR(100) AS brand,
    li.value:part:manufacturer::VARCHAR(200) AS manufacturer,
    li.value:part:container::VARCHAR(100) AS container,
    li.value:part:name::VARCHAR(200) AS name,
    li.value:part:partkey::INTEGER AS part_key,
    li.value:part:retailprice::DECIMAL(12,2) AS retail_price,
    li.value:part:type::VARCHAR(100) AS type,
    li.value:part:size::INTEGER AS size,
    li.value:extendedprice::DECIMAL(12,2) as extended_price,
    li.value:quantity::INTEGER AS quantity,
    li.value:tax::DECIMAL(6,4) AS tax,
    li.value:discount::DECIMAL(6,4) AS discount,
    li.value:extendedprice::DECIMAL(12,2) / li.value:quantity::INTEGER AS unit_price,
    (li.value:extendedprice::DECIMAL(12,2) - (li.value:extendedprice::DECIMAL(12,2) * li.value:discount::DECIMAL(6,4))) * li.value:tax::DECIMAL(6,4) AS tax_amt
FROM   prd_ent_order_source_db.orders.orders co,
LATERAL FLATTEN(INPUT => co.payload, PATH => 'lineitems') li;