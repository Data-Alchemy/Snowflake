-- write queries to show usage of dims/fact
--price + tax per customer
USE WAREHOUSE prd_ent_service_elt_whs;
USE DATABASE prd_ent_presentation_db;
USE SCHEMA sales;

SELECT 
SUM(fop.quantity * fop.unit_price) AS total_price,
SUM(fop.tax_amt) AS total_tax_amt,
c.name AS customer_name
FROM fact_order_price fop
INNER JOIN dim_customer c
  ON c.customer_id = fop.customer_id
GROUP BY
  c.name;


  

--price + tax by region
SELECT 
SUM(fop.quantity * fop.unit_price) AS total_price,
SUM(fop.tax_amt) AS total_tax_amt,
dl.region_name
FROM fact_order_price fop
INNER JOIN dim_customer dc
  ON dc.customer_id = fop.customer_id
INNER JOIN prd_ent_presentation_db.dimensions.dim_location dl
  ON dl.location_id = dc.customer_key
GROUP BY
  dl.region_name;


--total orders by nation, region
SELECT 
SUM(fop.quantity * fop.unit_price) AS total_price,
SUM(fop.tax_amt) AS total_tax_amt,
COUNT(DISTINCT d.order_key),
dl.region_name,
dl.country_name
FROM fact_order_price fop
INNER JOIN dim_customer dc
  ON dc.customer_id = fop.customer_id
INNER JOIN prd_ent_presentation_db.dimensions.dim_location dl
  ON dl.location_id = dc.location_id
INNER JOIN dim_orders d
  ON d.order_line_id = fop.order_line_id
GROUP BY
  dl.region_name,
  dl.country_name;
