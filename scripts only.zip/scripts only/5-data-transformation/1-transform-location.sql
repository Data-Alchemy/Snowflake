
/* we will populate the prod schema to facilitate following exercises */
USE ROLE SYSADMIN;

USE DATABASE prd_ent_integration_db;
USE SCHEMA derived;

USE WAREHOUSE prd_ent_service_elt_whs;

CREATE OR REPLACE TABLE location AS
SELECT n.n_nationkey AS nation_key,
  n.n_name AS country_name,
  n.n_comment AS country_comment,
  r.r_regionkey AS region_key,
  r.r_name AS region_name,
  r.r_comment AS region_comment
FROM prd_ent_crm_db.common.nation n
INNER JOIN prd_ent_crm_db.common.region r
ON r.r_regionkey = n.n_regionkey;


GRANT SELECT ON ALL TABLES IN SCHEMA prd_ent_integration_db.derived TO ROLE prd_ent_integration_db_readonly_role;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA prd_ent_integration_db.derived TO ROLE prd_ent_integration_db_crud_role;
