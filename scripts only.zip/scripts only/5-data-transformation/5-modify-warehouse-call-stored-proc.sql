
USE ROLE ent_service_elt_role;
USE WAREHOUSE prd_ent_service_elt_whs;

ALTER WAREHOUSE prd_ent_service_elt_whs SET WAREHOUSE_SIZE=MEDIUM MAX_CLUSTER_COUNT=2;

USE DATABASE prd_ent_integration_db;
USE SCHEMA derived;

TRUNCATE TABLE order_details;

call prd_ent_integration_db.utility.sp_load_order_details('prd_ent_integration_db','derived');

SELECT COUNT(*) FROM prd_ent_integration_db.derived.order_details;
