-- ------------------------------------------------------------
-- Name: 350 Generate Grants Script
--
-- Purpose: A utility to generate a standard set of READ, READ WRITE or READ WRITE CONTROL
--          grants from a schema to a set of roles.
--
--          Role names are always:  <Environment>_<Schema>_R
--
--			For example:            PROD_WORKING_R
--                                  PROD_WORKING_RW
--                                  PROD_WORKING_RWC
--
--          Note: This method assumes the schema was created with MANAGED ACCESS.
--
-- 
-- Copyright (c).  Snowflake 2020.  
-- ------------------------------------------------------------
-- Change History
-- Author        Date          Description
-- ------------------------------------------------------------
-- John Ryan     27-Apr-2020   Initial Version
-- ------------------------------------------------------------
-- ------------------------------------------------------------------------------------------------------------------------  
-- Create the Metadata Tables
-- ------------------------------------------------------------------------------------------------------------------------  


select current_schema(), current_role(), current_database();


create or replace table access_role_grants (
	access_type			varchar(30)
,   grant_type          varchar(30)
,	access_granted		varchar(200)
,   description         varchar(200)
);


create or replace table access_role_output (
	access_granted		varchar(200)
);


-- ------------------------------------------------------------------------------------------------------------------------  
-- Set up the metadata.  This is used to generate the grants 
-- Parameters are replaced by the stored procedure below:
--
-- $0 - Database.          eg. PROD_DWH
-- $1 - Schema.            eg. WORKING
-- $2 - Role.              eg. PROD_WORKING_R, PROD_WORKING_RW, PROD_WORKING_RWC 
-- ------------------------------------------------------------------------------------------------------------------------ 

truncate table access_role_grants;
insert into access_role_grants (access_type, grant_type, access_granted, description) values
       ('R',   'SCHEMA',  'grant usage on schema $1 to role $2',                            'USAGE               on SCHEMA'),
       ('R',   'DATABASE','grant usage on database $0 to role $2',                          'USAGE               on DATABASE'),
       ('RW',  'SCHEMA',  'grant usage on schema $1 to role $2',                            'USAGE               on SCHEMA'),
       ('RW',  'DATABASE','grant usage on database $0 to role $2',                          'USAGE               on DATABASE'),
       ('RWC', 'SCHEMA',  'grant usage on schema $1 to role $2',                            'USAGE               on SCHEMA'),
       ('RWC', 'DATABASE','grant usage on database $0 to role $2',                          'USAGE               on DATABASE'),       
       
       ('R', 'CURRENT','grant select on all tables in schema $1 to role $2',                'SELECT              on TABLES'),
       ('R', 'CURRENT','grant select on all views  in schema $1 to role $2',                'SELECT              on VIEWS'),
       ('R', 'CURRENT','grant usage, read on all stages in schema $1 to role $2',           'USAGE, READ         on STAGES'),
       ('R', 'CURRENT','grant usage on all file formats in schema $1 to role $2',           'USAGE               on FILE FORMATS'),
       ('R', 'CURRENT','grant select on all streams in schema $1 to role $2',               'SELECT              on STREAMS'),
       ('R', 'CURRENT','grant usage on all procedures in schema $1 to role $2',             'USAGE               on PROCEDURES'),
       ('R', 'CURRENT','grant usage on all functions in schema $1 to role $2',              'USAGE               on FUNCTIONS'),  
       
       ('RW', 'CURRENT','grant select, insert, update, delete, references on all tables in schema $1 to role $2', 'SELECT,INSERT, UPDATE,DELETE, REFERENCES on TABLES'),
       ('RW', 'CURRENT','grant select on all views  in schema $1 to role $2',               'SELECT              on VIEWS'),
       ('RW', 'CURRENT','grant usage, read, write on all stages in schema $1 to role $2',   'USAGE, READ,WRITE   on STAGES'),
       ('RW', 'CURRENT','grant usage on all file formats in schema $1 to role $2',          'USAGE               on FILE FORMATS'),
       ('RW', 'CURRENT','grant select on all streams in schema $1 to role $2',              'SELECT              on STREAMS'),
       ('RW', 'CURRENT','grant usage on all procedures in schema $1 to role $2',            'USAGE               on PROCEDURES'),
       ('RW', 'CURRENT','grant usage on all functions in schema $1 to role $2',             'USAGE               on FUNCTIONS'),        
       ('RW', 'CURRENT','grant usage on all sequences in schema $1 to role $2',             'USAGE               on SEQUENCES'),
       ('RW', 'CURRENT','grant monitor, operate on all tasks in schema $1 to role $2',      'MONITOR, OPERATE    on TASKS'),
       
       ('RWC', 'CURRENT','grant ownership on all tables in schema $1 to role $2',           'OWNERSHIP           on TABLES'),
       ('RWC', 'CURRENT','grant ownership on all views  in schema $1 to role $2',           'OWNERSHIP           on VIEWS'),
       ('RWC', 'CURRENT','grant ownership on all stages in schema $1 to role $2',           'OWNERSHIP           on STAGES'),
       ('RWC', 'CURRENT','grant ownership on all file formats in schema $1 to role $2',     'OWNERSHIP           on FILE FORMATS'),
       ('RWC', 'CURRENT','grant ownership on all streams in schema $1 to role $2',          'OWNERSHIP           on STREAMS'),
       ('RWC', 'CURRENT','grant ownership on all procedures in schema $1 to role $2',       'OWNERSHIP           on PROCEDURES'),
       ('RWC', 'CURRENT','grant ownership on all functions in schema $1 to role $2',        'OWNERSHIP           on FUNCTIONS'),        
       ('RWC', 'CURRENT','grant ownership on all sequences in schema $1 to role $2',        'OWNERSHIP           on SEQUENCES'),
       ('RWC', 'CURRENT','grant ownership on all tasks in schema $1 to role $2',            'OWNERSHIP           on TASKS'),
       
       ('R', 'FUTURE','grant select on future tables in schema $1 to role $2',              'SELECT              on TABLES'),
       ('R', 'FUTURE','grant select on future views  in schema $1 to role $2',              'SELECT              on VIEWS'),
       ('R', 'FUTURE','grant usage, read on future stages in schema $1 to role $2',         'USAGE, READ         on STAGES'),
       ('R', 'FUTURE','grant usage on future file formats in schema $1 to role $2',         'USAGE               on FILE FORMATS'),
       ('R', 'FUTURE','grant select on future streams in schema $1 to role $2',             'SELECT              on STREAMS'),
       ('R', 'FUTURE','grant usage on future procedures in schema $1 to role $2',           'USAGE               on PROCEDURES'),
       ('R', 'FUTURE','grant usage on future functions in schema $1 to role $2',            'USAGE               on FUNCTIONS'), 
       
       ('RW', 'FUTURE','grant select, insert, update, delete, references on future tables in schema $1 to role $2', 'SELECT,INSERT, UPDATE,DELETE, REFERENCES on TABLES'),
       ('RW', 'FUTURE','grant select on future views  in schema $1 to role $2',             'SELECT              on VIEWS'),
       ('RW', 'FUTURE','grant usage, read, write on future stages in schema $1 to role $2', 'USAGE, READ,WRITE   on STAGES'),
       ('RW', 'FUTURE','grant usage on future file formats in schema $1 to role $2',        'USAGE               on FILE FORMATS'),
       ('RW', 'FUTURE','grant select on future streams in schema $1 to role $2',            'SELECT              on STREAMS'),
       ('RW', 'FUTURE','grant usage on future procedures in schema $1 to role $2',          'USAGE               on PROCEDURES'),
       ('RW', 'FUTURE','grant usage on future functions in schema $1 to role $2',           'USAGE               on FUNCTIONS'),        
       ('RW', 'FUTURE','grant usage on future sequences in schema $1 to role $2',           'USAGE               on SEQUENCES'),
       ('RW', 'FUTURE','grant monitor, operate on future tasks in schema $1 to role $2',    'MONITOR, OPERATE    on TASKS'),
       
       ('RWC', 'FUTURE','grant ownership on future tables in schema $1 to role $2',         'FUTURE OWNERSHIP    on TABLES'),
       ('RWC', 'FUTURE','grant ownership on future views  in schema $1 to role $2',         'FUTURE OWNERSHIP    on VIEWS'),
       ('RWC', 'FUTURE','grant ownership on future stages in schema $1 to role $2',         'FUTURE OWNERSHIP    on STAGES'),
       ('RWC', 'FUTURE','grant ownership on future file formats in schema $1 to role $2',   'FUTURE OWNERSHIP    on FILE FORMATS'),
       ('RWC', 'FUTURE','grant ownership on future streams in schema $1 to role $2',        'FUTURE OWNERSHIP    on STREAMS'),
       ('RWC', 'FUTURE','grant ownership on future procedures in schema $1 to role $2',     'FUTURE OWNERSHIP    on PROCEDURES'),
       ('RWC', 'FUTURE','grant ownership on future functions in schema $1 to role $2',      'FUTURE OWNERSHIP    on FUNCTIONS'),        
       ('RWC', 'FUTURE','grant ownership on future sequences in schema $1 to role $2',      'FUTURE OWNERSHIP    on SEQUENCES'),
       ('RWC', 'FUTURE','grant ownership on future tasks in schema $1 to role $2',          'FUTURE OWNERSHIP    on TASKS');

	   
	   
  -- ------------------------------------------------------------------------------------------------------------------------
  -- Routine to generate the set of Access Role Grants
  -- For example, to generate a set of grants from schema WORKING in environment PROD and database PROD_DWH 
  -- Use the following:
  --
  -- use role PROD_
  -- use database PROD_DWH;
  -- use schema WORKING;
  -- call gen_grants('PROD','WORKING');
  --
  -- This will set up grants to the following roles from schema WORKING:
  -- 
  -- PROD_WORKING_R
  -- PROD_WORKING_RW
  -- PROD_WORKING_RWC
  -- ------------------------------------------------------------------------------------------------------------------------  
  create or replace procedure gen_grants(environment   char,
                                         database      char,
                                         schema_name   char)
  returns float not null
  language javascript
  as     
  $$ 
    //
    // Generate the Standard set of Access Roles for each Schema
    //
    // var sql = "select distinct " + "'create or replace role '" + "||" + " access_type " + " from access_role_grants";
    var sql = "select distinct " + "'create or replace role '" + "||" + "'" + ENVIRONMENT + "_" + SCHEMA_NAME + "_" + "'" + "||" + " access_type " + " from access_role_grants";    
    var stmt = snowflake.createStatement( {sqlText: sql} );
    var rs = stmt.execute();    
    while (rs.next()) {
       var code = rs.getColumnValue(1);
       var sql2 = "insert into access_role_output values (" + "'" + code + ";'" + ")";
       var xstmt = snowflake.createStatement( {sqlText: sql2} );
       var xrs   = xstmt.execute();       
    }
    //
    // Generate the Grants from Schema to Access Roles
    //
    var sql = "select replace(replace(replace(access_granted || '_' || access_type,'$1'," + "'" + SCHEMA_NAME + "'" + "), '$2', " + "'" + ENVIRONMENT + "_" + SCHEMA_NAME + "'), '$0', " + "'" + DATABASE + "')" + " from access_role_grants g";
    var stmt = snowflake.createStatement( {sqlText: sql} );
    var rs = stmt.execute();
    // Execute results
    while (rs.next())  {
       var code = rs.getColumnValue(1);
       var sql2 = "insert into access_role_output values (" + "'" + code + ";'" + ")";
       var xstmt = snowflake.createStatement( {sqlText: sql2} );
       var xrs   = xstmt.execute();
       }
  return 0.0;
  $$
  ;
 
  
-- ------------------------------------------------------------------------------------------------------------------------  
-- Execute routine to generate grants for a schema
-- ------------------------------------------------------------------------------------------------------------------------  
  
  truncate table access_role_output;
  call gen_grants('PROD', 'PROD_DWH', 'WORKING');
  select * from access_role_output;





  