-- ------------------------------------------------------------
-- Name: 300 RBAC - Sample Environent Grant Script
--
-- Purpose: Provides a sample script to create the necessary
--          privileges to manage an environment including a 
--          database and a single schema.
--
--          This can be used alongside the set of RBAC slides
--          in the Advanced RBAC QuickStart deck to deliver
--          the roles needed to manage an environment.
--
-- Note: 	This script delivers a single PROD environment
--			Consisting of:
--
--			1. Environment Management Roles:
--
--					PROD_ROLE_ADMIN - Role Admin for PROD
--					PROD_SYS_ADMIN  - System Admin for PROD
--
-- 			2. Functional Roles (Example roles only):
--
--					prod_data_scientist
--					prod_data_analyst
--					prod_devops
--					
--			3. Production database and a single schema
--
--					Database:   PROD_DWH
--					Schema:		working
--
--			4. Production Access Roles (Which control access to data)
--
--					prod_working_r		- Read access
--					prod_working_rw		- Read Write access
--					prod_working_rwc	- Read Write Control (full) access
--
--
-- 			Recommend:  Amend this script as follows:
--
--			a) Replace the Functional Roles with the actual roles needed
--			b) Replace the Database and Schema with actual databsase name and schemas
--			c) Create a set of Access Roles for each schemas as needed
--			d) Generate the grants from Schemas to Access Roles
--			e) Repeat the process replacing PROD with TEST and DEV as needed.
--
--
-- Copyright (c).  Snowflake 2020.  
-- ------------------------------------------------------------
-- Change History
-- Author        Date          Description
-- ------------------------------------------------------------
-- John Ryan     27-Apr-2020   Initial Version
-- ------------------------------------------------------------


-- ------------------------------------------------------------
-- Create environment Manager Roles
-- ------------------------------------------------------------
use role useradmin;
create or replace role PROD_role_admin;
create or replace role PROD_sys_admin;

-- ------------------------------------------------------------
-- Grant environment manager roles to current user
-- ------------------------------------------------------------
use role useradmin;
grant role PROD_role_admin to user analyticstoday;
grant role PROD_sys_admin  to user analyticstoday;

-- ------------------------------------------------------------
-- Grant Additional Privileges
-- ------------------------------------------------------------
use role sysadmin;
grant create database on account to role PROD_sys_admin;

use role useradmin;
grant create role on account to role PROD_role_admin;

-- ------------------------------------------------------------
-- Grant to SYSADMIN
-- ------------------------------------------------------------
use role useradmin;

grant role PROD_sys_admin to role SYSADMIN;

-- ------------------------------------------------------------
-- Create Functional Roles
-- ------------------------------------------------------------
use role PROD_role_admin;

create or replace role prod_data_scientist;
create or replace role prod_data_analyst;
create or replace role prod_devops;
	
-- ------------------------------------------------------------
-- Create Access Roles
-- ------------------------------------------------------------	

create or replace role prod_working_r;
create or replace role prod_working_rw;
create or replace role prod_working_rwc;


-- ------------------------------------------------------------
-- Grant to SYSADMIN
-- ------------------------------------------------------------
use role PROD_role_admin;

grant role PROD_data_scientist  to role PROD_sys_admin;
grant role PROD_data_analyst	to role PROD_sys_admin;
grant role PROD_working_r		to role PROD_sys_admin;
grant role PROD_working_rw		to role PROD_sys_admin;
grant role PROD_working_rwc		to role PROD_sys_admin;

-- ------------------------------------------------------------
-- Create Database
-- ------------------------------------------------------------
use role prod_sys_admin;

create or replace database PROD_DWH;

create schema WORKING with managed access;
   
-- ------------------------------------------------------------
-- Grants from Schema/Database to Access Roles
-- NOTE: The grants are generated using script GEN_GRANTS()
-- ------------------------------------------------------------   
use role prod_sys_admin;
use database prod_dwh;
use schema working;


grant usage on schema WORKING to role PROD_WORKING_R;
grant usage on database PROD_DWH to role PROD_WORKING_R;
grant usage on schema WORKING to role PROD_WORKING_RW;
grant usage on database PROD_DWH to role PROD_WORKING_RW;
grant all privileges on schema WORKING to role PROD_WORKING_RWC;
grant usage on database PROD_DWH to role PROD_WORKING_RWC;
grant select on all tables in schema WORKING to role PROD_WORKING_R;
grant select on all views  in schema WORKING to role PROD_WORKING_R;
grant usage, read on all stages in schema WORKING to role PROD_WORKING_R;
grant usage on all file formats in schema WORKING to role PROD_WORKING_R;
grant select on all streams in schema WORKING to role PROD_WORKING_R;
grant usage on all procedures in schema WORKING to role PROD_WORKING_R;
grant usage on all functions in schema WORKING to role PROD_WORKING_R;
grant select, insert, update, delete, references on all tables in schema WORKING to role PROD_WORKING_RW;
grant select on all views  in schema WORKING to role PROD_WORKING_RW;
grant usage, read, write on all stages in schema WORKING to role PROD_WORKING_RW;
grant usage on all file formats in schema WORKING to role PROD_WORKING_RW;
grant select on all streams in schema WORKING to role PROD_WORKING_RW;
grant usage on all procedures in schema WORKING to role PROD_WORKING_RW;
grant usage on all functions in schema WORKING to role PROD_WORKING_RW;
grant usage on all sequences in schema WORKING to role PROD_WORKING_RW;
grant monitor, operate on all tasks in schema WORKING to role PROD_WORKING_RW;
grant ownership on all tables in schema WORKING to role PROD_WORKING_RWC;
grant ownership on all views  in schema WORKING to role PROD_WORKING_RWC;
grant ownership on all stages in schema WORKING to role PROD_WORKING_RWC;
grant ownership on all file formats in schema WORKING to role PROD_WORKING_RWC;
grant ownership on all streams in schema WORKING to role PROD_WORKING_RWC;
grant ownership on all procedures in schema WORKING to role PROD_WORKING_RWC;
grant ownership on all functions in schema WORKING to role PROD_WORKING_RWC;
grant ownership on all sequences in schema WORKING to role PROD_WORKING_RWC;
grant ownership on all tasks in schema WORKING to role PROD_WORKING_RWC;
grant select on future tables in schema WORKING to role PROD_WORKING_R;
grant select on future views  in schema WORKING to role PROD_WORKING_R;
grant usage, read on future stages in schema WORKING to role PROD_WORKING_R;
grant usage on future file formats in schema WORKING to role PROD_WORKING_R;
grant select on future streams in schema WORKING to role PROD_WORKING_R;
grant usage on future procedures in schema WORKING to role PROD_WORKING_R;
grant usage on future functions in schema WORKING to role PROD_WORKING_R;
grant select, insert, update, delete, references on future tables in schema WORKING to role PROD_WORKING_RW;
grant select on future views  in schema WORKING to role PROD_WORKING_RW;
grant usage, read, write on future stages in schema WORKING to role PROD_WORKING_RW;
grant usage on future file formats in schema WORKING to role PROD_WORKING_RW;
grant select on future streams in schema WORKING to role PROD_WORKING_RW;
grant usage on future procedures in schema WORKING to role PROD_WORKING_RW;
grant usage on future functions in schema WORKING to role PROD_WORKING_RW;
grant usage on future sequences in schema WORKING to role PROD_WORKING_RW;
grant monitor, operate on future tasks in schema WORKING to role PROD_WORKING_RW;
grant ownership on future tables in schema WORKING to role PROD_WORKING_RWC;
grant ownership on future views  in schema WORKING to role PROD_WORKING_RWC;
grant ownership on future stages in schema WORKING to role PROD_WORKING_RWC;
grant ownership on future file formats in schema WORKING to role PROD_WORKING_RWC;
grant ownership on future streams in schema WORKING to role PROD_WORKING_RWC;
grant ownership on future procedures in schema WORKING to role PROD_WORKING_RWC;
grant ownership on future functions in schema WORKING to role PROD_WORKING_RWC;
grant ownership on future sequences in schema WORKING to role PROD_WORKING_RWC;
grant ownership on future tasks in schema WORKING to role PROD_WORKING_RWC;

-- ------------------------------------------------------------
-- Grant to Functional Roles
-- ------------------------------------------------------------   
use role prod_role_admin;

grant role prod_working_rw 		to role prod_data_analyst;
grant role prod_working_rwc 	to role prod_data_scientist;
grant role prod_working_rwc 	to role prod_DevOps;

-- ------------------------------------------------------------
-- Grant to Users
-- ------------------------------------------------------------ 
use role prod_role_admin;

grant role prod_data_analyst to user analyticstoday;
grant role prod_data_scientist to user analyticstoday;
grant role prod_DevOps to user analyticstoday;
    
-- ------------------------------------------------------------
-- Create tables and test 
-- ------------------------------------------------------------   
    
